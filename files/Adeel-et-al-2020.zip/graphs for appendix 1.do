clear all

cd "C:/Users/az310/Dropbox/COVID and institutions/Canada paper/replication files/export"
 
use cpp_sample,clear 
keep if cntry=="CA" 
 
encode region, gen(regnum)
tsset regnum date
 
twoway (tsline ppi_subn, lpattern(dash)) ///
(tsline ppi_nat, lpattern(dash_dot)) ///
(tsline ppi_total, lpattern(solid)), ///
by(regnum, cols(2) note("")) xtitle("") ysize(6) ylab(,angle(0)) xsize(15) scheme(s1color) ///
legend(rows(1) symxsize(5) size(small)) ///
tlabel(01feb2020 01mar2020 01apr2020, format(%dm_d) ) ///
nodraw name(trends,replace) 

graph display trends, ysize(10) xsize(7)
graph export "Canada trends by province.pdf", as(pdf) replace

**** USA
use cpp_sample,clear 
keep if cntry=="US" 
 
encode region, gen(regnum)
tsset regnum date
 
recode regnum (1/18=1)(19/36=2)(nonmiss=3), gen(group) 
save temp,replace

forval j = 1/3 {
use temp,clear
keep  if group==`j'
twoway (tsline ppi_subn, lpattern(dash)) ///
(tsline ppi_nat, lpattern(dash_dot)) ///
(tsline ppi_total, lpattern(solid)), ///
by(regnum, cols(3) note("")) xtitle("") ysize(6) ylab(,angle(0)) xsize(15) scheme(s1color) ///
legend(rows(1) symxsize(5) size(small)) ///
tlabel(01feb2020 01mar2020 01apr2020, format(%dm_d) ) ///
nodraw name(trends,replace) 

graph display trends, ysize(10) xsize(7)
graph export "US trends page `j'.pdf", as(pdf) replace
}

rm "temp.dta"