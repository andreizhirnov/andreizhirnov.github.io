library(ggplot2)
library(ggrepel)
library(gridExtra)
library(cluster)
library(sf)
library(rnaturalearth)
library(foreign)
library(lmtest)
library(plm)

theme_set(theme_bw())

rm(list=ls())
# setwd()

index <- read.dta("cpp_sample.dta")

##################################################################
#################### Figures in the manuscript ###################

## aggregate trends 
index.fed <- subset(index, rcode %in% c("NY","ON"), select = c("cntry","date","ppi_nat"))
 
ave <- within(index, {
     windex_state <- ppi_subn*population
     windex_final <- ppi_total*population
})
ave <- aggregate(cbind(windex_state, windex_final, population) ~ date + cntry, data=ave, FUN=sum)
index.ave <- within(ave, {
  date <- as.Date(date)
  windex_state <- windex_state/population
  windex_final <- windex_final/population
})

df <- merge(index.fed[c("cntry","date","ppi_nat")], index.ave[c("cntry","date","windex_state","windex_final")], by =c("cntry","date"))

pic <-  ggplot() +
  geom_line(data=subset(index, cntry=="US"), mapping=aes(x=date,y=ppi_subn, linetype="state", group=rcode, color="state"), alpha=0.5) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=ppi_nat, linetype="federal", color="federal")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=windex_state, linetype="weighted", color="weighted")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=windex_final, linetype="total", color="total")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%b %d") +
  scale_linetype_manual("type",breaks=c("federal","state","weighted","total"), values=c("solid", "dashed","dashed","dotdash"),labels=c("Federal","State","Avg State","Avg Total")) + 
  scale_color_manual("type",breaks=c("federal","state","weighted","total"), values=c("red", "green","darkgreen","blue"), labels=c("Federal","State","Avg State","Avg Total")) +
  labs(y="Policy Index") +
  theme(legend.title= element_blank(), 
        axis.title.y = element_text(size=14),
        axis.text = element_text(size=12),
        axis.title.x = element_blank(), 
        legend.text = element_text(size=14),
        legend.position = "bottom",
        legend.key.width = unit(1.6,"cm")) 
ggsave("figure1.pdf", pic, height=5, width=7)

pic <- ggplot() +
  geom_line(data=subset(index, cntry=="CA"),mapping=aes(x=date,y=ppi_subn, linetype="state", group=rcode, color="state"), alpha=0.5) +
  geom_line(data=subset(df, cntry=="CA"), mapping=aes(x=date, y=ppi_nat, linetype="federal", color="federal")) +
  geom_line(data=subset(df, cntry=="CA"), mapping=aes(x=date, y=windex_state, linetype="weighted", color="weighted")) +
  geom_line(data=subset(df, cntry=="CA"), mapping=aes(x=date, y=windex_final, linetype="total", color="total")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%b %d") +
  scale_linetype_manual("type",breaks=c("federal","state","weighted","total"), values=c("solid", "dashed","dashed","dotdash"),labels=c("Federal","Province","Avg Province","Avg Total")) + 
  scale_color_manual("type",breaks=c("federal","state","weighted","total"), values=c("red", "green","darkgreen","blue"), labels=c("Federal","Province","Avg Province","Avg Total")) +
  labs(y="Policy Index") +
  theme(legend.title= element_blank(), 
        axis.title.y = element_text(size=14),
        axis.text = element_text(size=12),
        axis.title.x = element_blank(), 
        legend.text = element_text(size=14),
        legend.position = "bottom",
        legend.key.width = unit(1.6,"cm"))  
ggsave("figure2.pdf", pic, height=5, width=7)

## bar plots with cumulative PPI
cum.index <- aggregate(ppi_subn ~ cntry + rcode, data=index,FUN=sum)
health.slice <- subset(index, date==as.Date("2020-3-22"), select=c("cntry","rcode","drate"))
df <- merge(cum.index, health.slice, by =c("cntry","rcode"))

dl <- lapply(c("US","CA"), function(x) subset(df, cntry==x))
names(dl) <- c("US","CA")

dl <- lapply(dl, function(x) {
  thresh <- median(x$drate[x$drate>0])
  within(x, {
    group <- rep(3,length(drate))
    group[drate<thresh] <- 2  
    group[drate==0] <- 1
    group <- ordered(group, levels=c(1,2,3), 
                     labels=c("0",
                              paste0("0.01-",format(thresh,digits=2)),
                              paste("above",format(thresh,digits=2))))
  })
})

dfdr <- dl[["US"]]
dfdr <- dfdr[order(dfdr$ppi_subn),] 
dfdr[["sort"]] <- 1:nrow(dfdr)
dfdr[["stla"]] <- paste0(dfdr$rcode,c("","----"))

pic <- ggplot(data=dfdr, aes(x=reorder(stla, sort), y=ppi_subn)) + 
  geom_bar(stat="identity", fill="blue", width=0.4,
           position = position_dodge(width=0.5)) + 
  labs(y="Cumulative Subnational PPI by 24-Apr-2020", x=element_blank()) +
  theme(axis.text.x = element_text(size=8, color="black"), axis.title = element_text(size=10, color="black"),
        aspect.ratio=1.6,plot.margin=grid::unit(c(0,0,0,0), "mm"))  + 
  coord_flip()
ggsave("figure3a.pdf", pic, height=6, width=5)

dfdr <- dl[["US"]]
dfdr <- dfdr[order(dfdr$drate),] 
dfdr[["sort"]] <- 1:nrow(dfdr)
dfdr[["stla"]] <- paste0(dfdr$rcode,c("","----"))

pic <- ggplot(data=dfdr, aes(x=reorder(stla, sort), y=ppi_subn, fill=group)) + 
  geom_bar(stat="identity", width=0.8,
           position = position_dodge(width=0.2)) + 
  scale_fill_manual(values=c("yellow","orange","red")) +
  scale_y_continuous(breaks=seq(0,1600,by=200)) +
  labs(y="Cumulative Subnational PPI by 24-Apr-2020", 
       fill="Deaths\nper million\non March 22", x="") +
  theme(axis.text.x = element_text(size=8, color="black"), axis.title = element_text(size=10, color="black"),
        aspect.ratio=1.6,plot.margin=grid::unit(c(0,0,0,0), "mm"))  + 
  coord_flip() 
ggsave("figure5a.pdf", pic, height=6, width=5)

pic <-ggplot(data=dl[["CA"]], aes(x=reorder(rcode,ppi_subn), y=ppi_subn)) + 
  geom_bar(stat="identity", fill="blue", width=0.7,
           position = position_dodge(width=0.3)) + 
  labs(y="Cumulative Subnational PPI by 24-Apr-2020", x="") +
  coord_flip()
ggsave("figure3b.pdf", pic, height=3, width=5) 

pic <- ggplot(data=dl[["CA"]], aes(x=reorder(rcode,ppi_subn), y=ppi_subn, fill=group)) + 
  geom_bar(stat="identity", width=0.8,
           position = position_dodge(width=0.2)) + 
  scale_fill_manual(values=c("yellow","orange","red")) +
  scale_y_continuous(breaks=seq(0,1600,by=200)) +
  labs(y="Cumulative Subnational PPI by 24-Apr-2020", 
       fill="Deaths\nper million\non March 22", x="") +
  theme(axis.text = element_text(size=8, color="black"),axis.title = element_text(size=10, color="black") )  +
  coord_flip() 
ggsave("figure5b.pdf", pic, height=3, width=5)


## maps  -- information for labels
labs <- unique(index[c("cntry","rcode")]) 
labs <- within(labs, {
  lab.ea <- rcode
  lab.no <- rcode
  lab.re <- rcode
  lab.ea[!(rcode %in% c("NH","MA","NJ","CT","MD","DC","RI","VA","MD","DE","NS","PE"))] <- NA
  lab.no[!(rcode %in% c("VT","ME"))] <- NA  
  lab.re[rcode %in% c(lab.ea,lab.no,"AK","HI")] <- NA  
})
 
## maps -- location data
maps <- ne_states(country = c("united states of america","canada"), returnclass = "sf") 
maps <- maps[c("iso_a2","postal","longitude","latitude","geometry")]
colnames(maps) <- c("cntry","rcode","long","lat","geometry")
maps <-  merge(maps, labs, by=c("cntry","rcode"))

base <- ne_countries(country = "Canada", returnclass = "sf")
box <- st_bbox(base)
box["ymin"] <- 55
base <- st_crop(base, box)

## a fuction for extracting legends
g_legend<-function(a.gplot){
  tmp <- ggplot_gtable(ggplot_build(a.gplot))
  leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
  legend <- tmp$grobs[[leg]]
  return(legend)}

## maps with death rates
maxd <- 15

# datasets
health.maps <- merge(maps, health.slice, by=c("cntry","rcode"))

# legend
mainland <- ggplot(data = health.maps, mapping=aes(geometry=geometry)) +
  geom_sf(aes(fill = drate)) + 
  scale_fill_gradient("COVID deaths per 1 mln",limits=c(0,maxd), low="white", high="darkred") + 
  theme(legend.position = "bottom", axis.title = element_blank())
mylegend <- g_legend(mainland)

# plotting
mainland <- ggplot(data = subset(health.maps, cntry=="US"), mapping=aes(geometry=geometry)) +
  geom_sf(aes(fill = drate)) + 
  scale_fill_gradient("COVID deaths per 1 mln",limits=c(0,maxd), low="white", high="darkred") +
  geom_text(aes(label=lab.re),  size=2, stat="sf_coordinates") +
  geom_text_repel(aes(label=lab.no), min.segment.length = 0, nudge_y=1000000, force=2, size=2, stat="sf_coordinates") +
  geom_text_repel(aes(label=lab.ea), min.segment.length = 0, nudge_x=1000000, force=2, size=2, stat="sf_coordinates") +
  coord_sf(crs = st_crs(2163), xlim = c(-2500000, 2500000), ylim = c(-2300000, 730000)) +
  theme(legend.position = "none", axis.title = element_blank())
alaska <- ggplot(data = subset(health.maps, cntry=="US"), mapping=aes(geometry=geometry)) +
  geom_sf(aes(fill = drate)) + 
  scale_fill_gradient(limits=c(0,maxd), low="white", high="darkred")+ 
  coord_sf(crs = st_crs(3467),
           xlim = c(-2400000, 1600000), 
           ylim = c(200000, 2500000), 
           expand = FALSE, datum = NA) + 
  annotate("text",  x=-1800000, y = 2000000, size=2, label = "AK") +
  theme(legend.position = "none", axis.title = element_blank(),
        axis.text = element_blank(), panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.background = element_rect(color = "black"))
hawaii <- ggplot(data = subset(health.maps, cntry=="US"), mapping=aes(geometry=geometry)) +
  geom_sf(aes(fill = drate)) + 
  scale_fill_gradient(limits=c(0,maxd), low="white", high="darkred")+ 
  coord_sf(crs = st_crs(4135), xlim = c(-161, -154), ylim = c(18, 23), 
           expand = FALSE, datum = NA) +
  annotate("text",  x=-160, y = 19, size=2, label = "HI") +
  theme(legend.position = "none", axis.title = element_blank(),
        axis.text = element_blank(), panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.background = element_rect(color = "black"))
us <- mainland +
  annotation_custom(
    grob = ggplotGrob(alaska),
    xmin = -2800000,
    xmax = -2800000 + (2000000 - (-2400000))/3.2,
    ymin = -2500000,
    ymax = -2500000 + (3000000 - 200000)/3.2
  ) +
  annotation_custom(
    grob = ggplotGrob(hawaii),
    xmin = -1400000,
    xmax = -1400000 + (-154 - (-161))*150000,
    ymin = -2500000,
    ymax = -2500000 + (23 - 18)*150000
  ) +
  theme(plot.margin=unit(c(0,0,-4,0), "cm"))

canada <-  
  ggplot(data = subset(health.maps, cntry=="CA"), mapping=aes(geometry=geometry)) +
  geom_sf(data=base, color="gray") +
  geom_sf(aes(fill = drate)) + 
  scale_fill_gradient("COVID\ndeaths\nper 1 mln",limits=c(0,maxd), low="white", high="darkred") +
  geom_text(aes(label=lab.re, x=long, y=lat), size=2) +
  geom_text_repel(aes(label=lab.ea, x=long, y=lat), min.segment.length = 0, nudge_x=1000000, force=2, size=2) +
  theme(legend.position = "none", axis.title = element_blank(), plot.margin=unit(c(0,0,-3.5,0), "cm"))

pic <- arrangeGrob(arrangeGrob(us, canada,nrow=1, widths=c(1.5, 1)), mylegend, nrow=2, heights=c(7, 1))
ggsave("figure4a.pdf", pic, height=5, width=7)
 
### maps with policies
cuts <- as.Date(c("2020-3-12","2020-3-22","2020-4-12","2020-4-23"))
slices <- subset(index, date %in% cuts)
slices <- merge(maps, slices, by = c("cntry","rcode"))
 
df <- subset(slices, date==cuts[2] & cntry=="US")

mainland <- ggplot(data = df, mapping=aes(geometry=geometry)) +
  geom_sf(aes(fill = ppi_subn)) + 
  scale_fill_gradient(limits=c(0,35), low="white", high="darkgreen") +
  labs(fill="Subnational PPI", size="Deaths\nper 1mln", x=element_blank(),y=element_blank()) +
  theme(legend.position="bottom")
mylegend<-g_legend(mainland)

# US

plots <- list()
for (i in 1:4) {
  df <- subset(slices, date==cuts[i] & cntry=="US")
  mark <- as.character(cuts[i])
  mainland <- ggplot(data = df, mapping=aes(geometry=geometry)) +
    geom_sf(aes(fill = ppi_subn)) +
    geom_text(aes(label=lab.re), size=2, stat = "sf_coordinates") +
    geom_text_repel(aes(label=lab.no), min.segment.length = 0, nudge_y=1000000, force=2, size=2, stat = "sf_coordinates") +
    geom_text_repel(aes(label=lab.ea), min.segment.length = 0, nudge_x=1000000, force=2, size=2, stat = "sf_coordinates") +
    scale_fill_gradient(limits=c(0,35), low="white", high="darkgreen") + 
    coord_sf(crs = st_crs(2163), xlim = c(-2500000, 2500000), ylim = c(-2300000, 730000)) +
    theme(legend.position = "none", axis.title = element_blank()) + ggtitle(mark)
  alaska <- ggplot(data = df, mapping=aes(geometry=geometry)) +
    geom_sf(aes(fill = ppi_subn)) + 
    scale_fill_gradient(limits=c(0,35), low="white", high="darkgreen")+ 
    coord_sf(crs = st_crs(3467),
             xlim = c(-2400000, 1600000), 
             ylim = c(200000, 2500000), 
             expand = FALSE, datum = NA) +
    annotate("text",  x=-1800000, y = 2000000, size=3, label = "AK") +
    theme(legend.position = "none", axis.title = element_blank(),
          axis.text = element_blank(), panel.grid.major = element_blank(), 
          panel.grid.minor = element_blank(),
          plot.background = element_rect(color = "black"))
  hawaii <- ggplot(data = df, mapping=aes(geometry=geometry)) +
    geom_sf(aes(fill = ppi_subn)) + 
    scale_fill_gradient(limits=c(0,35), low="white", high="darkgreen")+ 
    coord_sf(crs = st_crs(4135), xlim = c(-161, -154), ylim = c(18, 23), 
             expand = FALSE, datum = NA) +
    annotate("text",  x=-160, y = 19, size=3, label = "HI") +
    theme(legend.position = "none", axis.title = element_blank(),
          axis.text = element_blank(), panel.grid.major = element_blank(), 
          panel.grid.minor = element_blank(),
          plot.background = element_rect(color = "black"))
  plots[[i]] <- mainland +
    annotation_custom(
      grob = ggplotGrob(alaska),
      xmin = -2800000,
      xmax = -2800000 + (2000000 - (-2400000))/3.2,
      ymin = -2500000,
      ymax = -2500000 + (3000000 - 200000)/3.2
    ) +
    annotation_custom(
      grob = ggplotGrob(hawaii),
      xmin = -1400000,
      xmax = -1400000 + (-154 - (-161))*150000,
      ymin = -2500000,
      ymax = -2500000 + (23 - 18)*150000
    )
}

pic <- arrangeGrob(arrangeGrob(grobs=plots,nrow=2), mylegend, nrow=2,heights=c(9, 1))
ggsave("figure4b.pdf", pic, height=7, width=10) 

# Canada
plots <- list()
for (i in 1:4) {
  df <- subset(slices, date==cuts[i] & cntry=="CA")
  mark <- as.character(cuts[i])
  plots[[i]] <- ggplot(data = df, mapping=aes(geometry=geometry)) +
    geom_sf(data=base, color="gray") +
    geom_sf(aes(fill = ppi_subn)) +
    geom_text(aes(label=lab.re, x=long, y=lat), size=2) +
    geom_text_repel(aes(label=lab.ea, x=long, y=lat),
                    min.segment.length = 0, nudge_x=1000000, force=2, size=2) +
    scale_fill_gradient(limits=c(0,35), low="white", high="darkgreen") + 
    theme(legend.position = "none", axis.title = element_blank(), plot.margin=unit(c(0.5,-0.5,0.5,-0.5), "cm")) + ggtitle(mark)
}

pic <- arrangeGrob(arrangeGrob(grobs=plots,nrow=2), mylegend, nrow=2,heights=c(9, 1))
ggsave("figure4c.pdf", pic, height=7, width=8) 
 
######################################################
####################  Appendix 2 #####################

temp <- within(subset(index, date==max(index$date)), {
  ratio.st <- ppi_subn/ppi_total
  ratio.fed <- ppi_nat/ppi_total
})[c("cntry","rcode","ratio.st","ratio.fed","ppi_subn","ppi_nat","ppi_total")]

temp.us <- subset(temp, cntry=="US")
colnames(temp.us) <- c("Country","State","Subnational PPI/Combined PPI",
                    "Federal PPI/Combined PPI","Subnational PPI",
                    "Federal PPI","Combined PPI")
write.csv(temp.us,"Ratios US.csv", row.names = FALSE)

temp.ca <- subset(temp, cntry=="CA")
colnames(temp.ca) <- c("Country","Province","Subnational PPI/Combined PPI",
                    "Federal PPI/Combined PPI","Subnational PPI",
                    "Federal PPI","Combined PPI")
write.csv(temp.ca,"Ratios Canada.csv", row.names = FALSE)

#############################################################################
###### Supplement 5: The early-threat indicators and the subnational PPI ####

index.test <- within(index, {
  grate <- drate + 0.01* irate
  isocode <- paste0(cntry,"-",rcode)
})

codes <- unique(index.test$isocode)
names(codes) <- codes

df.list <- lapply(codes, function(x) {
  y <- subset(index.test, isocode==x)
  y <- y[order(y$date),]
  y
})

# death rate -> index
tests.grates.fw <- lapply(df.list, function(x) {
  x1 <- grangertest(ppi_subn ~ grate, order = 5, data = x)
  x2 <- grangertest(ppi_subn ~ grate, order = 10, data = x)
  data.frame(gF5=x1[2,3], gp5=x1[2,4],gF10=x2[2,3], gp10=x2[2,4])
}) 
# incidence rate -> index
tests.irates.fw <- lapply(df.list, function(x) {
  x1 <- grangertest(ppi_subn ~ irate, order = 5, data = x)
  x2 <- grangertest(ppi_subn ~ irate, order = 10, data = x)
  data.frame(iF5=x1[2,3], ip5=x1[2,4],iF10=x2[2,3], ip10=x2[2,4])
})
tests.rates.fw <- cbind(codes,do.call("rbind", tests.irates.fw),do.call("rbind", tests.grates.fw))

# index -> death rate
tests.grates.bw <- lapply(df.list, function(x) {
  x1 <- grangertest(grate ~ ppi_subn, order = 5, data = x)
  x2 <- grangertest(grate ~ ppi_subn, order = 10, data = x)
  data.frame(gF5=x1[2,3], gp5=x1[2,4],gF10=x2[2,3], gp10=x2[2,4])
})

# index -> incidence rate
tests.irates.bw <- lapply(df.list, function(x) {
  x1 <- grangertest(irate ~ ppi_subn, order = 5, data = x)
  x2 <- grangertest(irate ~ ppi_subn, order = 10, data = x)
  data.frame(iF5=x1[2,3], ip5=x1[2,4],iF10=x2[2,3], ip10=x2[2,4])
})
tests.rates.bw <- cbind(codes,do.call("rbind", tests.irates.bw),do.call("rbind", tests.grates.bw))

write.csv(tests.rates.fw, "tests-rates-fw.csv", row.names=FALSE) 
write.csv(tests.rates.bw, "tests-rates-bw.csv", row.names=FALSE) 


#############################################################################
####### Supplement 3: PPI vs IRT-based index ################################

## correlation coefficients
with(index, cor(ppi_subn, str_irt_subn, use = 'complete.obs'))
with(index, cor(ppi_total, str_irt_total, use = 'complete.obs'))

## chart
index.fed <- subset(index, rcode %in% c("NY","ON"), select = c("cntry","date","ppi_nat","str_irt_nat"))
index.st <- na.omit(index)

ave <- within(index, {
  windex_state <- ppi_subn*population
  wirt_state <- str_irt_subn*population 
})
ave <- aggregate(cbind(windex_state, wirt_state, population) ~ date + cntry, data=ave, FUN=sum)
index.ave <- within(ave, {
  date <- as.Date(date)
  windex_state <- windex_state/population
  wirt_state <- wirt_state/population
})

df <- merge(index.fed, index.ave[c("cntry","date","windex_state","wirt_state")], by =c("cntry","date"))

pic_sc <- ggplot() +
  geom_line(data=subset(index.st, cntry=="CA"), mapping=aes(x=date,y=str_irt_subn, linetype="state", group=rcode, color="state")) +
  geom_line(data=subset(df, cntry=="CA"), mapping=aes(x=date, y=str_irt_nat, linetype="federal", color="federal")) +
  geom_line(data=subset(df, cntry=="CA"), mapping=aes(x=date, y=wirt_state, linetype="weighted", color="weighted")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%b %d") +
  scale_linetype("type",labels=c("Federal","Province","Average Province (weighted)")) + 
  scale_color_manual("type",values=c("black", "gray","black"), labels=c("Federal","Province","Average Province (weighted)")) +
  labs(y="Policy Index", title="IRT-based index in Canada") +
  theme(legend.title= element_blank(), 
        axis.title.y = element_text(size=14),
        axis.text = element_text(size=12),
        axis.title.x = element_blank(), 
        legend.text = element_text(size=14),
        legend.position = "none") 
 
pic_su <- ggplot() +
  geom_line(data=subset(index.st, cntry=="US"), mapping=aes(x=date,y=str_irt_subn, linetype="state", group=rcode, color="state")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=str_irt_nat, linetype="federal", color="federal")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=wirt_state, linetype="weighted", color="weighted")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%b %d") +
  scale_linetype("type",labels=c("Federal","State","Average State (weighted)")) + 
  scale_color_manual("type",values=c("black", "gray","black"), labels=c("Federal","State","Average State (weighted)")) +
  labs(y="Policy Index", title="IRT-based index in the US") +
  theme(legend.title= element_blank(), 
        axis.title.y = element_text(size=14),
        axis.text = element_text(size=12),
        axis.title.x = element_blank(), 
        legend.text = element_text(size=14),
        legend.position = "none") 

pic_pc <- ggplot() +
  geom_line(data=subset(index.st, cntry=="CA"), mapping=aes(x=date,y=ppi_subn, linetype="state", group=rcode, color="state")) +
  geom_line(data=subset(df, cntry=="CA"), mapping=aes(x=date, y=ppi_nat, linetype="federal", color="federal")) +
  geom_line(data=subset(df, cntry=="CA"), mapping=aes(x=date, y=windex_state, 
                                 linetype="weighted", color="weighted")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%b %d") +
  scale_linetype("type",labels=c("Federal","Province","Average Province (weighted)")) + 
  scale_color_manual("type",values=c("black", "gray","black"), labels=c("Federal","Province","Average Province (weighted)")) +
  labs(y="Policy Index", title="PPI in Canada") +
  theme(legend.title= element_blank(), 
        axis.title.y = element_text(size=14),
        axis.text = element_text(size=12),
        axis.title.x = element_blank(), 
        legend.text = element_text(size=14),
        legend.position = "none") 

pic_pu <- ggplot() +
  geom_line(data=subset(index.st, cntry=="US"), mapping=aes(x=date,y=ppi_subn, linetype="state", group=rcode, color="state")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=ppi_nat, linetype="federal", color="federal")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=windex_state, linetype="weighted", color="weighted")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%b %d") +
  scale_linetype("type",labels=c("Federal","State","Average State (weighted)")) + 
  scale_color_manual("type",values=c("black", "gray","black"), labels=c("Federal","State","Average State (weighted)")) +
  labs(y="Policy Index", title="PPI in the US") +
  theme(legend.title= element_blank(), 
        axis.title.y = element_text(size=14),
        axis.text = element_text(size=12),
        axis.title.x = element_blank(), 
        legend.text = element_text(size=14),
        legend.position = "none")

forleg <- ggplot() +
  geom_line(data=subset(index.st, cntry=="US"),mapping=aes(x=date,y=ppi_subn, linetype="state", group=rcode, color="state")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=ppi_nat, linetype="federal", color="federal")) +
  geom_line(data=subset(df, cntry=="US"), mapping=aes(x=date, y=windex_state, linetype="weighted", color="weighted")) +
  scale_x_date(date_breaks = "2 weeks", date_labels = "%b %d") +
  scale_linetype("type",labels=c("Federal","Subnational","Average Subnational")) + 
  scale_color_manual("type",values=c("black", "gray","black"), labels=c("Federal","Subnational","Average Subnational")) +
  labs(y="Policy Index", title="PPI in the US") +
  theme(legend.title= element_blank(), 
        axis.title.y = element_text(size=14),
        axis.text = element_text(size=12),
        axis.title.x = element_blank(), 
        legend.text = element_text(size=14),
        legend.position = "bottom")

mylegend<-g_legend(forleg)


pic <- grid.arrange(arrangeGrob(grobs=list(pic_sc,pic_su,pic_pc,pic_pu),nrow=2), mylegend, nrow=2,heights=c(9, 1))
ggsave('ppi vs irt.pdf', pic, height=7, width=9) 

## Granger tests

# death rate -> index
tests.grates.fw <- lapply(df.list, function(x) {
  x1 <- grangertest(str_irt_subn ~ grate, order = 5, data = x)
  x2 <- grangertest(str_irt_subn ~ grate, order = 10, data = x)
  data.frame(gF5=x1[2,3], gp5=x1[2,4],gF10=x2[2,3], gp10=x2[2,4])
}) 
# incidence rate -> index
tests.irates.fw <- lapply(df.list, function(x) {
  x1 <- grangertest(str_irt_subn ~ irate, order = 5, data = x)
  x2 <- grangertest(str_irt_subn ~ irate, order = 10, data = x)
  data.frame(iF5=x1[2,3], ip5=x1[2,4],iF10=x2[2,3], ip10=x2[2,4])
})
tests.rates.fw <- cbind(codes,do.call("rbind", tests.irates.fw),do.call("rbind", tests.grates.fw))

# index -> death rate
tests.grates.bw <- lapply(df.list, function(x) {
  x1 <- grangertest(grate ~ str_irt_subn, order = 5, data = x)
  x2 <- grangertest(grate ~ str_irt_subn, order = 10, data = x)
  data.frame(gF5=x1[2,3], gp5=x1[2,4],gF10=x2[2,3], gp10=x2[2,4])
})

# index -> incidence rate
tests.irates.bw <- lapply(df.list, function(x) {
  x1 <- grangertest(irate ~ str_irt_subn, order = 5, data = x)
  x2 <- grangertest(irate ~ str_irt_subn, order = 10, data = x)
  data.frame(iF5=x1[2,3], ip5=x1[2,4],iF10=x2[2,3], ip10=x2[2,4])
})
tests.rates.bw <- cbind(codes,do.call("rbind", tests.irates.bw),do.call("rbind", tests.grates.bw))

write.csv(tests.rates.fw, "tests-rates-fw-sup.csv", row.names=FALSE) 
write.csv(tests.rates.bw, "tests-rates-bw-sup.csv", row.names=FALSE) 


