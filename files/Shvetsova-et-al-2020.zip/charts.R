library(ggplot2)
library(foreign)

theme_set(theme_minimal())

rm(list=ls())
options(stringsAsFactors = FALSE)
setwd("C:/Users/az310/Dropbox/COVID and institutions/JPIPE paper/replication/export")

spsta <- as.Date("2020-2-15")
spend <- as.Date("2020-4-1")

country <- read.dta("df_country.dta")
countrydate <- read.dta("df_countrydate.dta")

df <- merge(country,countrydate, by="ccode")

df <- within(df, {  
  democracy <- cut(polity2, breaks=c(-11,-7,6.99,11), labels=c("-7 and below", "between -6 and 6", "7 and above"), ordered_result = TRUE)
  fed <- ordered(federation, levels=c(0,1), labels=c("Non Federations", "Federations"))
  parl <- ordered(parliam, levels=c(0,1), labels=c("Presidential/semipresidential", "Parliamentary")) 
  decen <- cut(n_selfrule, breaks=c(-1,9.99,20,40),labels=c("below 10", "between 10 and 20", "over 10"), ordered_result = TRUE)
  free <- as.numeric(fh_status %in% c('F','PF'))
  fh_sta <- ordered(fh_status, levels=c("NF","PF","F"), labels=c("Not Free", "Partially Free", "Free"))
  t <- as.numeric(date-date_posc) 
  date <- as.Date(date, origin = "1960-01-01")
 })

dem <- ggplot(data=df, aes(x=date, y=ppi, linetype=democracy, fill=democracy, group=democracy), color="black", alpha=0.2) +  
  scale_linetype_manual("Polity", values=c("dotted","dashed","solid"), na.translate=FALSE) +   
  scale_fill_manual("Polity", values=c("yellow","green","blue"), na.translate=FALSE) +   
  geom_smooth(method = 'gam', formula = y ~ s(x, bs = "cs")) + scale_x_date(date_breaks="2 weeks", labels=scales::date_format("%m/%d")) + 
  labs(y="PPI",x=element_blank(), caption="Estimates of GAM with cubic splines")  +
  theme(legend.position="bottom") 
ggsave("figure2.pdf", plot=dem , width=7, height=5)

dem <- ggplot(data=df, aes(x=date, y=ppi, linetype=fh_sta, fill=fh_sta, group=fh_sta), color="black", alpha=0.2) +  
  scale_linetype_manual("FH Status", values=c("dotted","dashed","solid"), na.translate=FALSE) +   
  scale_fill_manual("FH Status", values=c("yellow","green","blue"), na.translate=FALSE) +   
  geom_smooth(method = 'gam', formula = y ~ s(x, bs = "cs")) + scale_x_date(date_breaks="2 weeks", labels=scales::date_format("%m/%d")) + 
  labs(y="PPI",x=element_blank(), caption="Estimates of GAM with cubic splines")  +
  theme(legend.position="bottom") 
ggsave("figure3.pdf", plot=dem , width=7, height=5)


## figure 5
dem <- ggplot(data=subset(df, free==1), aes(x=date, y=ppi, linetype=fed, fill=fed, group=fed), color="black", alpha=0.2) +  
  scale_linetype_manual("Federalism", values=c("dashed","solid"), na.translate=FALSE) +   
  scale_fill_manual("Federalism", values=c("yellow","blue"), na.translate=FALSE) +   
  geom_smooth(method = 'gam', formula = y ~ s(x, bs = "cs")) + scale_x_date(date_breaks="2 weeks", labels=scales::date_format("%m/%d")) + 
  labs(y="PPI",x=element_blank(), caption="Estimates of GAM with cubic splines; 'not-free' polities are excluded.")  +
  theme(legend.position="bottom") 
ggsave("figure5.pdf", plot=dem , width=7, height=5)

## figure 6
part <- subset(df, date %in% as.Date(c("2020-3-15","2020-4-1")) & free==1, select = c("ccode","n_selfrule","date","ppi_n","ppi_s"))
stacked_c <- reshape(part, direction="long", v.names = "ppi", varying=c("ppi_n","ppi_s"), times=c("n","s"), timevar="level")
stacked_c <- within(stacked_c, level <- ordered(level, levels=c('s','n'), labels=c("Subnational","National")))

dem <- ggplot(data=stacked_c, aes(x=n_selfrule, y=ppi, fill=level, linetype=level, group=interaction(level, date))) +
  geom_point(aes(color=level, shape=level)) + geom_smooth(method="gam", formula=y ~ s(x, bs = "cs"), color="black", alpha=0.4) +
  scale_linetype_manual("Policy Level", values=c("solid","dotted"), na.translate=FALSE) +
  scale_shape_manual("Policy Level", values=c(16,17), na.translate=FALSE) +
  scale_color_manual("Policy Level", values=c("blue","darkgreen"), na.translate=FALSE) +
  scale_fill_manual("Policy Level", values=c("blue","darkgreen"), na.translate=FALSE) +
  labs(x="Selfrule component of RAI", y="PPI", caption="GAM estimates") +
  facet_grid(. ~ date) + theme(legend.position="bottom") 
ggsave("figure6.pdf", plot=dem , width=8, height=5) 

## S4
dem <- ggplot(data=subset(df, t>=0 & t<=75), aes(x=t, y=ppi, linetype=democracy, fill=democracy, group=democracy), color="black", alpha=0.2) +  
  scale_linetype_manual("Polity", values=c("dotted","dashed","solid"), na.translate=FALSE) +   
  scale_fill_manual("Polity", values=c("yellow","green","blue"), na.translate=FALSE) +   
  geom_smooth(method = 'gam', formula = y ~ s(x, bs = "cs")) +
  labs(y="PPI",x="Days since the first COVID case", caption="Estimates of GAM with cubic splines")  +
  theme(legend.position="bottom") 
ggsave("figure S4-1.pdf", plot=dem , width=7, height=5) 

dem <- ggplot(data=subset(df, t>=0 & t<=75), aes(x=t, y=ppi, linetype=fh_sta, fill=fh_sta, group=fh_sta), color="black", alpha=0.2) +  
  scale_linetype_manual("FH Status", values=c("dotted","dashed","solid"), na.translate=FALSE) +   
  scale_fill_manual("FH Status", values=c("yellow","green","blue"), na.translate=FALSE) +   
  geom_smooth(method = 'gam', formula = y ~ s(x, bs = "cs")) + 
  labs(y="PPI",x="Days since the first COVID case", caption="Estimates of GAM with cubic splines")  +
  theme(legend.position="bottom") 
ggsave("figure S4-2.pdf", plot=dem , width=7, height=5)

dem <- ggplot(data=subset(df, free==1 & t>=0 & t<=75), aes(x=t, y=ppi, linetype=fed, fill=fed, group=fed), color="black", alpha=0.2) +  
  scale_linetype_manual("Federalism", values=c("dashed","solid"), na.translate=FALSE) +   
  scale_fill_manual("Federalism", values=c("yellow","blue"), na.translate=FALSE) +   
  geom_smooth(method = 'gam', formula = y ~ s(x, bs = "cs")) + 
  labs(y="PPI", x="Days since the first COVID case", caption="Estimates of GAM with cubic splines; 'not-free' polities are excluded.")  +
  theme(legend.position="bottom") 
ggsave("figure S4-3.pdf", plot=dem , width=7, height=5)


dem <- ggplot(data=subset(df, free==1), aes(x=date, y=ppi, linetype=parl, fill=parl, group=parl), color="black", alpha=0.2) +  
  scale_linetype_manual("", values=c("dashed","solid"), na.translate=FALSE) +   
  scale_fill_manual("", values=c("yellow","blue"), na.translate=FALSE) +   
  geom_smooth(method = 'gam', formula = y ~ s(x, bs = "cs")) + scale_x_date(date_breaks="2 weeks", labels=scales::date_format("%m/%d")) + 
  labs(y="PPI",x=element_blank(), caption="Estimates of GAM with cubic splines; 'not-free' polities are excluded.")  +
  theme(legend.position="bottom") 
ggsave("figure S4-4.pdf", plot=dem , width=7, height=5)

## variance differences by regime type as of March 15 - S5
ppi.means <- aggregate(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-3-15")), FUN=mean)
ppi.var <- aggregate(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-3-15")), FUN=var)
ppi.N <- aggregate(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-3-15")), FUN=length)
data.frame(ppi.means, var =ppi.var[["ppi"]], N=ppi.N[["ppi"]])
var.test(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-3-15") & fh_status %in% c('F','NF')),  alternative = "two.sided")
var.test(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-3-15") & fh_status %in% c('F','PF')),  alternative = "two.sided") 

## variance differences by federalism as of March 15 - S5
ppi.means <- aggregate(ppi ~ federation, data=subset(df, date==as.Date("2020-3-15") & free==1), FUN=mean)
ppi.var <- aggregate(ppi ~ federation, data=subset(df, date==as.Date("2020-3-15") & free==1), FUN=var)
ppi.N <- aggregate(ppi ~ federation, data=subset(df, date==as.Date("2020-3-15") & free==1), FUN=length)
data.frame(ppi.means, var =ppi.var[["ppi"]], N=ppi.N[["ppi"]])
var.test(ppi ~ federation, data=subset(df, date==as.Date("2020-3-15") & free==1),  alternative = "two.sided") 

## variance differences by regime type as of April 1 - S5
ppi.means <- aggregate(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-4-1")), FUN=mean)
ppi.var <- aggregate(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-4-1")), FUN=var)
ppi.N <- aggregate(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-4-1")), FUN=length)
data.frame(ppi.means, var =ppi.var[["ppi"]], N=ppi.N[["ppi"]])
var.test(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-4-1") & fh_status %in% c('F','NF')),  alternative = "two.sided")
var.test(ppi ~ fh_sta, data=subset(df, date==as.Date("2020-4-1") & fh_status %in% c('F','PF')),  alternative = "two.sided") 

## variance differences by federalism as of April 1 - S5
ppi.means <- aggregate(ppi ~ federation, data=subset(df, date==as.Date("2020-4-1") & free==1), FUN=mean)
ppi.var <- aggregate(ppi ~ federation, data=subset(df, date==as.Date("2020-4-1") & free==1), FUN=var)
ppi.N <- aggregate(ppi ~ federation, data=subset(df, date==as.Date("2020-4-1") & free==1), FUN=length)
data.frame(ppi.means, var =ppi.var[["ppi"]], N=ppi.N[["ppi"]])
var.test(ppi ~ federation, data=subset(df, date==as.Date("2020-4-1") & free==1),  alternative = "two.sided")