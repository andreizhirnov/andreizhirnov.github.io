**********************************************************************************
** Part of the replication materials for
** Institutional Origins of Protective COVID-19 Public Health Policy Responses: 
** Informational and Authority Redundancies and Policy Stringency 
** by Olga Shvetsova, Andrei Zhirnov, Julie VanDusky Allen, Abdul Basit Adeel, 
** Michael Catalano, Olivia Catalano, Frank Giannelli, Ezgi Muftuoglu, Tara Riggs,
** Mehmet Halit Sezgin, Naveed Tahir, and Tianyi Zhaoi 
***********************************************************************************

clear all
set more off
cd "C:/Users/az310/Dropbox/COVID and institutions/JPIPE paper/replication/export"

global controls = "wdi_pop65 wdi_popden hl_spen" 
global controls2 = "wdi_gdpcappppcon2011 wdi_trade doctors" 

use df_countrydate, clear
merge m:1 ccode using df_country, nogenerate

* encode Freedom status
encode fh_status, gen(fh0)
lab var fh0 "Freedom Status"

recode polity2 (7/10=1)(-10/-7=2)(nonmiss=3), gen(democracy)
lab var democracy "Polity Range"

* use the COVID incidence in the adjacent countries if it is higher
replace irate=irate_nei if irate_nei>irate & !mi(irate_nei)

* log skewed variables
replace wdi_popden=ln(wdi_popden)
replace wdi_gdpcappppcon2011=ln(wdi_gdpcappppcon2011) 
replace hl_spen=ln(hl_spen)

lab var wdi_popden "(ln) Population density"
lab var wdi_gdpcappppcon2011 "(ln) GDP per capita" 
lab var hl_spen "(ln) Healthcare spending"

xtset ccode date

save temp,replace

** regime and PPI, cross-national data
use temp,clear

eststo mp1: regress ppi i.fh0 if date==mdy(3,15,2020), robust
eststo mp2: regress ppi i.fh0 L7.irate $controls if date==mdy(3,15,2020), robust
eststo mp3: regress ppi i.fh0 L7.irate $controls $controls2 if date==mdy(3,15,2020), robust

eststo mp4: regress ppi polity2 if date==mdy(3,15,2020), robust
eststo mp5: regress ppi polity2 L7.irate $controls if date==mdy(3,15,2020), robust
eststo mp6: regress ppi polity2 L7.irate $controls $controls2  if date==mdy(3,15,2020), robust

eststo mp7: regress ppi v2x_polyarchy if date==mdy(3,15,2020), robust
eststo mp8: regress ppi v2x_polyarchy L7.irate $controls if date==mdy(3,15,2020), robust
eststo mp9: regress ppi v2x_polyarchy L7.irate $controls $controls2  if date==mdy(3,15,2020), robust

eststo mp10: regress ppi v2x_libdem if date==mdy(3,15,2020), robust
eststo mp11: regress ppi v2x_libdem L7.irate $controls if date==mdy(3,15,2020), robust
eststo mp12: regress ppi v2x_libdem L7.irate $controls $controls2  if date==mdy(3,15,2020), robust

eststo ap1: regress ppi i.fh0 if date==mdy(4,1,2020), robust
eststo ap2: regress ppi i.fh0 L7.irate $controls if date==mdy(4,1,2020), robust
eststo ap3: regress ppi i.fh0 L7.irate $controls $controls2  if date==mdy(4,1,2020), robust

eststo ap4: regress ppi polity2 if date==mdy(4,1,2020), robust
eststo ap5: regress ppi polity2 L7.irate $controls if date==mdy(4,1,2020), robust
eststo ap6: regress ppi polity2 L7.irate $controls $controls2  if date==mdy(4,1,2020), robust

eststo ap7: regress ppi v2x_polyarchy if date==mdy(4,1,2020), robust
eststo ap8: regress ppi v2x_polyarchy L7.irate $controls if date==mdy(4,1,2020), robust
eststo ap9: regress ppi v2x_polyarchy L7.irate $controls $controls2  if date==mdy(4,1,2020), robust

eststo ap10: regress ppi v2x_libdem if date==mdy(4,1,2020), robust
eststo ap11: regress ppi v2x_libdem L7.irate $controls if date==mdy(4,1,2020), robust
eststo ap12: regress ppi v2x_libdem L7.irate $controls $controls2  if date==mdy(4,1,2020), robust
 
esttab mp1 mp2 mp3 mp4 mp5 mp6 ap1 ap2 ap3 ap4 ap5 ap6 using "table1.csv", csv replace b(%10.3f) ///
 se stats(r2 ar2 N, labels("R-squared" "Adj R-squared" "Obs") fmt(%10.3f %10.3f %10.0f)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
 nomtitles label ///
 varlabels(_cons Constant) nonote addnote("Robust standard errors in parentheses. * p<0.1, ** p<0.05 *** p< 0.01 for two-tailed tests.") 

esttab mp7 mp8 mp9 mp10 mp11 mp12 using "estimates-S3-1.csv", csv replace b(%10.3f) ///
 se stats(r2 ar2 N, labels("R-squared" "Adj R-squared" "Obs") fmt(%10.3f %10.3f %10.0f)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
 nomtitles label ///
 varlabels(_cons Constant) nonote addnote("Robust standard errors in parentheses. * p<0.1, ** p<0.05 *** p< 0.01 for two-tailed tests.") 
 
esttab ap7 ap8 ap9 ap10 ap11 ap12 using "estimates-S3-2.csv", csv replace b(%10.3f) ///
 se stats(r2 ar2 N, labels("R-squared" "Adj R-squared" "Obs") fmt(%10.3f %10.3f %10.0f)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
 nomtitles label ///
 varlabels(_cons Constant) nonote addnote("Robust standard errors in parentheses. * p<0.1, ** p<0.05 *** p< 0.01 for two-tailed tests.") 

*** regime and PPI, panel data analysis
use temp,clear
drop if date<mdy(2,15,2020)
drop if date>mdy(4,1,2020)

*** sys-GMM
eststo p1: xtabond2 ppi l.ppi i.fh0 l(0/2).irate, gmm(l.ppi irate, lag(15 15)) iv(i.fh0) cluster(ccode)
eststo p2: xtabond2 ppi l.ppi i.fh0 l(0/2).irate $controls , gmm(l.ppi irate, lag(15 15)) iv(i.fh0) iv($controls) cluster(ccode)
eststo p3: xtabond2 ppi l.ppi i.fh0 l(0/2).irate $controls $controls2  , gmm(l.ppi irate, lag(15 15)) iv(i.fh0) iv($controls) iv($controls2) cluster(ccode)

eststo p4: xtabond2 ppi l.ppi polity2 l(0/2).irate, gmm(l.ppi irate, lag(15 15)) iv(polity2) cluster(ccode)
eststo p5: xtabond2 ppi l.ppi polity2 l(0/2).irate $controls , gmm(l.ppi irate, lag(15 15)) iv(polity2) iv($controls) cluster(ccode)
eststo p6: xtabond2 ppi l.ppi polity2 l(0/2).irate $controls $controls2 , gmm(l.ppi irate, lag(15 15)) iv(polity2) iv($controls) iv($controls2) cluster(ccode)

eststo p7: xtabond2 ppi l.ppi v2x_polyarchy l(0/2).irate, gmm(l.ppi irate, lag(15 15)) iv(v2x_polyarchy) cluster(ccode) 
eststo p8: xtabond2 ppi l.ppi v2x_polyarchy l(0/2).irate $controls , gmm(l.ppi irate, lag(15 15)) iv(v2x_polyarchy) iv($controls) cluster(ccode)
eststo p9: xtabond2 ppi l.ppi v2x_polyarchy l(0/2).irate $controls $controls2 , gmm(l.ppi irate, lag(15 15)) iv(v2x_polyarchy) iv($controls) iv($controls2) cluster(ccode)

eststo p10: xtabond2 ppi l.ppi v2x_libdem l(0/2).irate, gmm(l.ppi irate, lag(15 15)) iv(v2x_libdem) cluster(ccode) 
eststo p11: xtabond2 ppi l.ppi v2x_libdem l(0/2).irate $controls , gmm(l.ppi irate, lag(15 15)) iv(v2x_libdem) iv($controls) cluster(ccode) 
eststo p12: xtabond2 ppi l.ppi v2x_libdem l(0/2).irate $controls $controls2 , gmm(l.ppi irate, lag(15 15)) iv(v2x_libdem) iv($controls) iv($controls2) cluster(ccode)

esttab p1 p2 p3 p4 p5 p6 p7 p8 p9 p10 p11 p12 using "table2.csv", csv replace b(%06.3g) ///
 se stats(chi2 chi2p N N_g ar1 ar1p ar2 ar2p, labels("Wald Chi-squared" "p" "N" "N groups" "AR(1) test" "p" "AR(2) test" "p") fmt(%10.1f %10.3f %10.0f %10.0f %10.3f %10.3f %10.3f %10.3f)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
 nomtitles label ///
 varlabels(_cons Constant) nonote addnote("Robust standard errors in parentheses (adjusted for clusters by country). * p<0.1, ** p<0.05 *** p< 0.01 for two-tailed tests.")
 
*** twoway FE
use temp,clear
drop if date<mdy(2,15,2020)
drop if date>mdy(4,1,2020)

qui reg ppi i.ccode i.fh0##i.date, cluster(ccode) 
collapse (min) ccode, by(date fh0)
replace ccode=840

predict xb,xb
predict se,stdp
gen ub = xb + 1.96*se
gen lb = xb - 1.96*se
 
twoway (rarea lb ub date if fh0==2, color(red%30))(rarea lb ub date if fh0==1, color(blue%30)) ///
(line xb date if fh0==2, color(red) lpattern("dash"))(line xb date if fh0==1, color(blue) lpattern("solid")), ///
ytitle("PPI") xtitle("") xlab(,format(%tdNN/DD)) legend(order(4 3) label(4 "Free") label(3 "Not Free") symxsize(*0.5) colgap(*0.5)) name(fnf,replace) nodraw fysize(50)
 
twoway (rarea lb ub date if fh0==3, color(green%30))(rarea lb ub date if fh0==1, color(blue%30)) ///
(line xb date if fh0==3, color(green) lpattern("dash"))(line xb date if fh0==1, color(blue) lpattern("solid")), ///
ytitle("PPI") xtitle("") xlab(,format(%tdNN/DD)) legend(order(4 3) label(4 "Free") label(3 "Partly Free") symxsize(*0.5) colgap(*0.5)) name(fpf,replace) nodraw fysize(50)
 
*** Polity 
use temp,clear
drop if date<mdy(2,15,2020)
drop if date>mdy(4,1,2020)

qui reg ppi i.ccode i.democracy##i.date, cluster(ccode)
egen newirate=mean(irate)
replace irate=newirate
collapse (mean) irate, by(date democracy)
gen ccode=840
predict xb,xb
predict se,stdp
gen ub = xb + 1.96*se
gen lb = xb - 1.96*se

twoway (rarea lb ub date if democracy==2, color(red%30))(rarea lb ub date if democracy==1, color(blue%30)) ///
(line xb date if democracy==2, color(red) lpattern("dash"))(line xb date if democracy==1, color(blue) lpattern("solid")), ///
ytitle("PPI") xtitle("") xlab(,format(%tdNN/DD)) legend(order(4 3) label(4 "Polity{&ge}7") label(3 "Polity{&le}-7") symxsize(*0.5) colgap(*0.5)) name(pfnf,replace) nodraw fysize(50)
 
twoway (rarea lb ub date if democracy==3, color(green%30))(rarea lb ub date if democracy==1, color(blue%30)) ///
(line xb date if democracy==3, color(green) lpattern("dash"))(line xb date if democracy==1, color(blue) lpattern("solid")), ///
ytitle("PPI") xtitle("") xlab(,format(%tdNN/DD)) legend(order(4 3) label(4 "Polity{&ge}7") label(3 "Polity from -6 and 6") symxsize(*0.5) colgap(*0.5)) name(pfpf,replace) nodraw fysize(50)

graph combine fnf fpf pfnf pfpf,ycommon
graph export figure4.pdf,replace

*** subnational vs national, cross-national data
use temp,clear
keep if inlist(fh0,3,1) 

eststo mp1: mvreg ppi_s ppi_n = n_selfrule if date==mdy(3,15,2020), corr
eststo mp2: mvreg ppi_s ppi_n = n_selfrule L7.irate $controls if date==mdy(3,15,2020), corr
eststo mp3: mvreg ppi_s ppi_n = n_selfrule L7.irate $controls2 if date==mdy(3,15,2020), corr
 
eststo ap1: mvreg ppi_s ppi_n  = n_selfrule if date==mdy(4,1,2020), corr
eststo ap2: mvreg ppi_s ppi_n  = n_selfrule L7.irate $controls if date==mdy(4,1,2020), corr
eststo ap3: mvreg ppi_s ppi_n  = n_selfrule L7.irate $controls2 if date==mdy(4,1,2020), corr
 
esttab mp1 mp2 mp3 using "estimates-S3-4.csv", csv replace b(%10.3f) ///
 se stats(r2 N, labels("R-squared" "Obs") fmt(%10.3f %10.0f)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
 nomtitles label unstack ///
 varlabels(_cons Constant) nonote addnote("Standard errors in parentheses. * p<0.1, ** p<0.05 *** p< 0.01 for two-tailed tests.") 
 
esttab ap1 ap2 ap3 using "estimates-S3-5.csv", csv replace b(%10.3f) ///
 se stats(r2 N, labels("R-squared" "Obs") fmt(%10.3f %10.0f)) starlevels(* 0.1 ** 0.05 *** 0.01) ///
 nomtitles label unstack ///
 varlabels(_cons Constant) nonote addnote("Standard errors in parentheses. * p<0.1, ** p<0.05 *** p< 0.01 for two-tailed tests.")