//////////////////////////////////////////////////////////////////
//////////////////////// descriptives
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear
hist sfratio,percent name(sfratio,replace) nodraw xtitle("") caption("Cox SF ratio")
hist enpv,percent  name(enpv,replace) nodraw xtitle("") caption("Effective number of parties in the district")
hist hlvote,percent  name(hlvote,replace) nodraw xtitle("") caption("Percent hopeless votes")
hist copproduct,percent  name(copproduct,replace) nodraw xtitle("") caption("Crisp-Olivella-Potter product")
graph combine sfratio enpv hlvote copproduct,cols(2)
graph export histdv.eps,replace

quietly regress hlvote medianinc newstv newspaper literate graduate enrel enlang scres stres,robust
sum sfratio enpv hlvote copproduct medianhha medianinc lnincomepc newstv newspaper literate graduate enrel enlang scres stres mark partymark if e(sample)
ds sfratio enpv hlvote copproduct medianhha medianinc lnincomepc newstv newspaper literate graduate enrel enlang scres stres,detail
corr sfratio enpv hlvote copproduct medianhha medianinc lnincomepc newstv newspaper literate graduate enrel enlang scres stres mark partymark if e(sample)

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////// main output
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear

// sfratio
foreach var in medianhha medianinc lnincomepc { 
regress sfratio `var',robust
outreg2 using table1,tex dec(2) label
}

foreach var in medianhha medianinc lnincomepc { 
regress sfratio `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres,robust
outreg2 using table1,tex  dec(2)  label
}

foreach var in medianhha medianinc lnincomepc { 
regress sfratio `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
outreg2 using table1,tex  dec(2)  label
}

// enpv
foreach var in medianhha medianinc lnincomepc { 
regress enpv `var',robust
outreg2 using table2,tex  dec(2)  label
}

foreach var in medianhha medianinc lnincomepc { 
regress enpv `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres,robust
outreg2 using table2,tex  dec(2)  label
}

foreach var in medianhha medianinc lnincomepc { 
regress enpv `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
outreg2 using table2,tex  dec(2)  label
}

// hlvote
foreach var in medianhha medianinc lnincomepc { 
regress hlvote `var',robust
outreg2 using table3,tex   dec(2)  label
}

foreach var in medianhha medianinc lnincomepc { 
regress hlvote `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres,robust
outreg2 using table3,tex  dec(2)  label
}

foreach var in medianhha medianinc lnincomepc { 
regress hlvote `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
outreg2 using table3,tex  dec(2)  label
}

// copproduct
foreach var in medianhha medianinc lnincomepc { 
regress copproduct `var',robust
outreg2 using table4,tex   dec(2)  label
}

foreach var in medianhha medianinc lnincomepc { 
regress copproduct `var' newstv newspaper literate graduate  c.enrel##c.enrel c.enlang##c.enlang scres stres,robust
outreg2 using table4,tex  dec(2)  label
}

foreach var in medianhha medianinc lnincomepc { 
regress copproduct `var' newstv newspaper literate graduate  c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
outreg2 using table4,tex  dec(2)  label beta
}

////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////// logging the dependent variables 
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear

foreach dv in sfratio enpv hlvote copproduct{
replace `dv'=ln(`dv')
foreach var in medianhha medianinc lnincomepc { 
regress `dv' `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
outreg2 using table5,excel dec(3) label
}
} 
seeout

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
///////////////////////// interactive effect
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear

foreach dv in sfratio enpv hlvote copproduct{ 
foreach var in medianhha medianinc lnincomepc { 
regress `dv' c.`var'##c.partymark newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres,robust
outreg2 using table5,excel dec(3) label
}
} 
seeout

////// marginal effects of interactive effects
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear

foreach dv in enpv hlvote copproduct{ 
foreach var in medianhha medianinc lnincomepc { 
quietly regress `dv' c.`var'##c.partymark newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres,robust
margins,dydx(`var') at(partymark=(5 12))
}
} 

//////////////////////////////////////////////////////////////////////////////////
///////////////////////


clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear
scalar x=1
foreach dv in sfratio enpv hlvote copproduct{ 
foreach var in medianhha medianinc lnincomepc{
quietly regress `dv' `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
quietly sum `dv' if e(sample),detail
scalar u1=`r(min)'
scalar u2=`r(p25)'
scalar u3=`r(p50)'
scalar u4=`r(p75)'
scalar u5=`r(max)' 
quietly sum `var' if e(sample),detail
scalar l1=`r(min)'
scalar l2=`r(p25)'
scalar l3=`r(p50)'
scalar l4=`r(p75)'
scalar l5=`r(max)'
quietly regress `dv' `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
quietly margins,at(`var'=(`=l1' `=l2' `=l3' `=l4' `=l5'))
marginsplot,yline(`=u2') yline(`=u3') yline(`=u4') xline(`=l1') xline(`=l2') xline(`=l3') xline(`=l4') xline(`=l5') ///
xlabel(#2) name(gr`=x',replace) nodraw title("") ytitle("") recastci(rline) ciopts(lpatter(dash)) fysize(40) fxsize(100)
scalar x=x+1
}
} 
graph combine gr1 gr2 gr3,cols(3) ycommon 
graph export sfratio.eps
graph combine gr4 gr5 gr6,cols(3) ycommon
graph export enpv.eps
graph combine gr7 gr8 gr9,cols(3) ycommon 
graph export hlvote.eps
graph combine gr10 gr11 gr12,cols(3) ycommon
graph export copproduct.eps

//////////////////////// the same in a tabular form

clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear 
foreach dv in sfratio enpv hlvote copproduct{ 
foreach var in medianhha medianinc{
quietly regress `dv' `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
quietly sum `var' if e(sample),detail
scalar l1=`r(min)'
scalar l2=`r(p25)'
scalar l3=`r(p50)'
scalar l4=`r(p75)'
scalar l5=`r(max)'
quietly regress `dv' `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
margins,at(`var'=(`=l1' `=l2' `=l3' `=l4' `=l5')) 
}
} 

pctile p_sfratio=sfratio if e(sample),genp(p_x) nq(100)
pctile p_hlvote=hlvote if e(sample),nq(100)
pctile p_enpv=enpv if e(sample),nq(100)
pctile p_copproduct=copproduct if e(sample),nq(100)
keep p_*

////
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear 
foreach dv in sfratio enpv hlvote copproduct{  
quietly regress `dv' lnincomepc newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
quietly sum lnincomepc if e(sample),detail
scalar l1=`r(min)'
scalar l2=`r(p25)'
scalar l3=`r(p50)'
scalar l4=`r(p75)'
scalar l5=`r(max)'
quietly regress `dv' lnincomepc newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
margins,at(lnincomepc =(`=l1' `=l2' `=l3' `=l4' `=l5')) 
} 

pctile p_sfratio=sfratio if e(sample),genp(p_x) nq(100)
pctile p_hlvote=hlvote if e(sample),nq(100)
pctile p_enpv=enpv if e(sample),nq(100)
pctile p_copproduct=copproduct if e(sample),nq(100)
keep p_*

////////////////////////////////////// graph interactive
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear
scalar x=1
foreach var in medianhha medianinc lnincomepc{
quietly regress hlvote `var' newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
quietly sum  hlvote if e(sample),detail
scalar u1=`r(min)'
scalar u2=`r(p25)'
scalar u3=`r(p50)'
scalar u4=`r(p75)'
scalar u5=`r(max)' 
quietly sum `var' if e(sample),detail
scalar l1=`r(min)'
scalar l2=`r(p25)'
scalar l3=`r(p50)'
scalar l4=`r(p75)'
scalar l5=`r(max)'
quietly regress hlvote c.`var'##c.partymark newstv newspaper literate graduate c.enrel##c.enrel c.enlang##c.enlang scres stres,robust
quietly margins,at(`var'=(`=l1' `=l2' `=l3' `=l4' `=l5') partymark=(5 12))
marginsplot,yline(`=u2') yline(`=u3') yline(`=u4') xline(`=l1') xline(`=l2') xline(`=l3') xline(`=l4') xline(`=l5') xdimension(`var') ///
xlabel(#2) name(gr`=x',replace) nodraw title("") ytitle("") recastci(rline) ciopts(lpatter(dash)) fysize(40) fxsize(100) ///
legend(off)
scalar x=x+1
}

graph combine gr1 gr2 gr3,cols(3) ycommon
graph export hlvoteinter.eps,replace

///////////////////////////////////////////////////////////////////////////////////
////////////////////////////// separate variables with the level of education

clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear

gen a=ln(literate)
gen b=ln(graduate/literate) 

foreach var in sfratio enpv hlvote copproduct { 
regress `var' medianhha newstv newspaper a b c.enrel##c.enrel c.enlang##c.enlang scres stres mark partymark,robust
outreg2 using table,excel dec(3)
}
seeout

/////////////////////////// religious fragmentation

clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear
foreach var in sfratio enpv hlvote copproduct { 
regress `var' medianhha newstv newspaper literate graduate enrel enlang scres stres if enrel<6,robust
outreg2 using table,excel dec(3)
}
seeout
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////   non-linear effect of the religious fragmentation
clear all
cd "/home/andrei/Desktop/Dropbox/indianelection/"
use working2009.dta,clear
gen lnincomepc=ln(incomepc)
gen enrel2=enrel^2
gen enlang2=enlang^2
foreach dv in sfratio enpv hlvote copproduct{
quietly regress `dv' medianhha medianinc newstv newspaper literate graduate enrel enrel2 enlang enlang2 scres stres,robust
}

quietly regress sfratio medianhha newstv newspaper literate graduate c.enrel c.enrel#c.enrel enlang enlang2 scres stres,robust
margins, dydx(enrel) at(enrel=(1(.1)8))

quietly regress enpv medianhha newstv newspaper literate graduate c.enrel c.enrel#c.enrel enlang enlang2 scres stres,robust
margins, dydx(enrel) at(enrel=(1(.1)8))

quietly regress hlvote  medianhha newstv newspaper literate graduate c.enrel c.enrel#c.enrel enlang enlang2 scres stres,robust
quietly margins, dydx(enrel) at(enrel=(1(.1)8))
marginsplot

quietly regress copproduct medianhha newstv newspaper literate graduate c.enrel c.enrel#c.enrel enlang enlang2 scres stres,robust
margins, dydx(enrel) at(enrel=(1(.1)8))
