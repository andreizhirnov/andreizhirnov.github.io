clear all 

/********************** Table 1 ******************************/
use mainfile,clear
drop if winshare>.5999
gen xahopeless=1 if projrunnerup!=votechoice&projwinner!=votechoice
replace xahopeless=0 if projrunnerup==votechoice|projwinner==votechoice
gen right=0
replace right=1 if (votechoice==winner|votechoice==runnerup)&(votechoice==projwinner|votechoice==projrunnerup)
replace right=1 if (votechoice!=winner&votechoice!=runnerup)&(votechoice!=projwinner&votechoice!=projrunnerup)
lab var right "Right about the viability of the candidate of their choice"
tab right
 
gen correct=0
replace correct=1 if (projrunnerup==runnerup|projrunnerup==winner)&(projwinner==runnerup|projwinner==winner) 
gen xphopeless=1
replace xphopeless=0 if votechoice==winner|votechoice==runnerup
gen infocat=4
replace infocat=1 if correct==1
replace infocat=2 if correct==0&right==1
replace infocat=3 if correct==0&right==0
replace infocat=4 if dnkwinner==1|dnkrunnerup==1
tab infocat
tab xahopeless infocat if infocat!=4,col nofreq
tab xphopeless infocat,col nofreq 


/****************** Tables 2 and 4 ****************************/
* impute values of the campaign spending variables
use addvarbyparty,clear
merge m:1 district using additionalvar,nogenerate
mi set wide
mi register imputed expenses
mi register regular voteshare oldshare incumbent prophomeowner propfrenchspeaking medincome
mi impute mvn expenses=voteshare oldshare incumbent prophomeowner propfrenchspeaking medincome, ///
add(50) dots rseed(339487731) force replace burnin(200)

mi passive: gen viabspend=xpviable*expenses
mi passive: egen spend_volume=sum(expenses),by(district)
mi passive: egen totviabspending=sum(viabspend),by(district)
sort district 
keep if district!=district[_n-1]
mi passive: gen spend_cf=(spend_volume-totviabspending)/spend_volume
keep district _mi_miss spend_volume *_spend_volume spend_cf *_spend_cf
tempfile campfin
save `campfin',replace

* main survey file
use mainfile,clear
gen right=0
gen xahopeless=1
replace xahopeless=0 if projrunnerup==votechoice|projwinner==votechoice
replace right=1 if (votechoice==winner|votechoice==runnerup)&(votechoice==projwinner|votechoice==projrunnerup)
replace right=1 if (votechoice!=winner&votechoice!=runnerup)&(votechoice!=projwinner&votechoice!=projrunnerup)

gen correct=0
replace correct=1 if (projrunnerup==runnerup|projrunnerup==winner)&(projwinner==runnerup|projwinner==winner) 
gen xphopeless=1
gen infocat=1 if correct==1
replace infocat=2 if correct==0&right==1
replace infocat=3 if correct==0&right==0
replace xphopeless=0 if votechoice==winner|votechoice==runnerup 

replace activ_volume=. if activ_volume==0 

mi set wide
mi register imputed activ_volume activ_cf campden contacted sidviable sidnviable 
mi register regular correct ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark ///
sfratio volatility prophomeowner propfrenchspeaking medincome
mi impute mvn activ_cf campden contacted sidviable sidnviable activ_volume = ///
correct ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark sfratio volatility prophomeowner propfrenchspeaking medincome, ///
add(50) dots rseed(339487731) force replace burnin(200) 

mi merge m:1 district using `campfin'

save imputeddata,replace
 
/******************************* Table 2 ***************************/
use imputeddata,clear
drop if winshare>.5999
foreach var of varlist _1_spend_volume _1_spend_cf _1_activ_cf _1_campden _1_contacted _1_activ_volume ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark sfratio {
drop if `var'==.
}
 
eststo m1: mi estimate,post: probit correct activ_volume,cluster(district)
matrix beta_m1=(e(b))
eststo m2: mi estimate,post: probit correct spend_volume,cluster(district)
matrix beta_m2=(e(b))
eststo m3: mi estimate,post: probit correct campden,cluster(district)
matrix beta_m3=(e(b))
eststo m4: mi estimate,post: probit correct activ_cf,cluster(district)
matrix beta_m4=(e(b))
eststo m5: mi estimate,post: probit correct spend_cf,cluster(district)
matrix beta_m5=(e(b))
eststo m6: mi estimate,post: probit correct activ_volume activ_cf ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark sfratio,cluster(district) 
matrix beta_m6=(e(b))
eststo m7: mi estimate,post: probit correct spend_volume spend_cf ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark sfratio,cluster(district)
matrix beta_m7=(e(b))
eststo m8: mi estimate,post: probit correct campden ptyid_volume ptyid_cf contacted interest wr_education wr_knowledge wr_tv partymark sfratio,cluster(district)
matrix beta_m8=(e(b))

esttab m1 m2 m3 m4 m5 m6 m7 m8 using "table1.tex", tex replace b(%10.3f) se stats(N N_clust F_mi,labels("Observations" "Clusters" "F") fmt(%10.0f %10.0f %10.2f)) starlevels(* 0.1 ** 0.02) ///
varlabels(_cons Constant) addnote("Standard errors in parentheses. One-tailed tests.") alignment(l) nogaps /// 
nodepvars label nonumbers compress nobase noomit obslast long mtitle("(1)" "(2)" "(3)" "(4)" "(5)" "(6)" "(7)" "(8)")

/******************************* Table 4 ***************************/
use imputeddata,clear 
foreach var of varlist _1_spend_cf _1_activ_cf _1_sidviable _1_sidnviable xphopeless correct partymark {
drop if `var'==.
}

eststo m9: mi estimate,post: probit xphopeless c.activ_cf i.correct,cluster(district)
matrix beta_m9=(e(b))
eststo m10: mi estimate,post: probit xphopeless c.activ_cf##i.correct,cluster(district)
matrix beta_m10=(e(b))
eststo m11: mi estimate,post: probit xphopeless c.activ_cf##i.correct partymark sidviable sidnviable,cluster(district)
matrix beta_m11=(e(b))

eststo m12: mi estimate,post: probit xphopeless c.spend_cf i.correct,cluster(district)
matrix beta_m12=(e(b))
eststo m13: mi estimate,post: probit xphopeless c.spend_cf##i.correct,cluster(district)
matrix beta_m13=(e(b))
eststo m14: mi estimate,post: probit xphopeless c.spend_cf##i.correct partymark sidviable sidnviable,cluster(district)
matrix beta_m14=(e(b))

esttab m9 m10 m11 m12 m13 m14 using "table2.tex", tex replace b(%10.2f) se stats(N N_clust F_mi,labels("Obs" "Clusters" "Model F") fmt(%10.0f %10.0f %10.2f)) starlevels(* 0.1 ** 0.02) ///
varlabels(_cons Constant) addnote("Standard errors in parentheses. One-tailed tests.") alignment(l) nogaps /// 
nodepvars label nonumbers compress nobase noomit obslast long mtitle("(9a)" "(9b)" "(9c)" "(10a)" "(10b)" "(10c)")

/************ Deviance calculations: use the coeffcients stored in the memory after the estimation ************/
matrix output=(0,0)
forvalues j = 1/8 {
tempvar est_xb est_correct dev
matrix score `est_xb'=beta_m`j'
quietly gen `est_correct'=normal(`est_xb')
quietly gen `dev'=-2*(correct*ln(`est_correct')+(1-correct)*ln(1-`est_correct'))
quietly sum `dev'
scalar devi=(r(mean))
matrix temp=(`j',`=devi')
matrix output=(output\temp)
}
 
forvalues j = 9/14{
tempvar est_xb est_correct dev
matrix score `est_xb'=beta_m`j'
quietly gen `est_correct'=normal(`est_xb')
quietly gen `dev'=-2*(xphopeless*ln(`est_correct')+(1-xphopeless)*ln(1-`est_correct'))
quietly sum `dev'
scalar devi=(r(mean))
matrix temp=(`j',`=devi')
matrix output=(output\temp)
}


clear
svmat output
export delimited deviances1,replace

/***************** Figure 2 *******************************/
use imputeddata,clear
drop if winshare>.5999
foreach var of varlist _1_spend_volume _1_spend_cf _1_activ_cf _1_campden _1_contacted _1_activ_volume ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark sfratio {
drop if `var'==.
}

save mysample,replace

foreach var of varlist campden activ_volume activ_cf spend_volume spend_cf ptyid_volume ptyid_cf contacted interest wr_education wr_knowledge wr_tv partymark sfratio {
quietly sum `var'
scalar mean`var'=(r(mean))
}

clear 
set obs 1
foreach var in campden activ_volume activ_cf spend_volume spend_cf ptyid_volume ptyid_cf contacted interest wr_education wr_knowledge wr_tv partymark sfratio {
gen `var'=`=mean`var''
}
gen fakedata=1
save fakedata,replace


use mysample,clear
mi estimate,post: probit correct campden ptyid_volume ptyid_cf contacted interest wr_education wr_knowledge wr_tv partymark sfratio,cluster(district)
use fakedata,clear
expand 13
replace campden=.4+(_n-1)*0.05
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist campden if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound campden if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred campden if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Density of campaign contacts") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(cctcampaign,replace)
 
use mysample,clear
mi estimate,post: probit correct activ_volume activ_cf ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark sfratio,cluster(district) 
use fakedata,clear
expand 21
replace activ_cf=(_n-1)*0.05
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist activ_cf if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound activ_cf if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred activ_cf if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Centrifugalism (activists)") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(activ_cf,replace)

use mysample,clear
mi estimate,post: probit correct spend_volume spend_cf ptyid_volume ptyid_cf interest wr_education wr_knowledge wr_tv partymark sfratio,cluster(district)
use fakedata,clear
expand 21
replace spend_cf=(_n-1)*0.05
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist spend_cf if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound spend_cf if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred spend_cf if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Centrifugalism (spending)") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(spend_cf,replace)

use fakedata,clear
expand 11
replace ptyid_volume=(_n-1)*0.05
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist ptyid_volume if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound ptyid_volume if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred ptyid_volume if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Prop. strong partisans") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(ptyid_volume,replace)

use fakedata,clear
expand 21
replace ptyid_cf=(_n-1)*0.05
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist ptyid_cf if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound ptyid_cf if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred ptyid_cf if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Centrifugalism (party id)") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(ptyid_cf,replace)
 
use fakedata,clear
expand 21
replace wr_knowledge =(_n-1)*0.05
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist wr_knowledge  if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound wr_knowledge  if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred wr_knowledge  if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Political knowledge") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(wr_knowledge ,replace)

use fakedata,clear
expand 11
replace interest =(_n-1)*1
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist interest  if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound interest if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred interest  if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Interest in federal election") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(interest,replace)
 
use fakedata,clear
expand 9
replace partymark =3+(_n-1)*1
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist partymark if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound partymark if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred partymark if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("Number of contesting parties") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(partymark,replace)

use fakedata,clear
expand 21
replace sfratio =(_n-1)*.05
predict xb,xb
predict se,stdp
gen pred=normal(xb)
gen lowerbound= normal(xb-1.95*se)
gen upperbound= normal(xb+1.95*se)
append using mysample
twoway (hist sfratio if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(outline)) /// 
(rline lowerbound upperbound sfratio if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(connected pred sfratio if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)),legend(off) ///
xtitle("3rd-ranked/ 2nd-ranked vote ratio") ytitle("Pr(correct)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(sfratio,replace)

graph combine cctcampaign activ_cf spend_cf ptyid_volume ptyid_cf interest wr_knowledge partymark sfratio,cols(3) ycommon
graph display,xsize(3) ysize(2.5)
graph export figure2.eps,replace


/*********************************** Figure 3 ********************************/
use imputeddata,clear
foreach var of varlist _1_spend_cf _1_activ_cf _1_sidviable _1_sidnviable xphopeless correct partymark {
drop if `var'==.
}

save mysample,replace

use mysample,clear
mi estimate,post saving(m6,replace): probit xphopeless c.spend_cf##i.correct partymark sidviable sidnviable,cluster(district)
foreach var of varlist partymark sidviable sidnviable {
quietly sum `var'
scalar mean`var'=(r(mean))
}
clear
set obs 21
foreach var in partymark sidviable sidnviable {
gen `var'=`=mean`var''
}

gen spend_cf=(_n-1)*0.05

gen correct=.
forvalues j = 0/1 {
replace correct=`j'
predict xb_mi`j',xb
predict se_mi`j',stdp
gen est_correct`j'=normal(xb_mi`j')
gen lowerbound`j'= normal(xb_mi`j'-1.95*se_mi`j')
gen upperbound`j'= normal(xb_mi`j'+1.95*se_mi`j')
}
gen fakedata=1
append using mysample
twoway (hist spend_cf if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(p10bar)) /// 
(rline lowerbound0 upperbound0 spend_cf if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(rline lowerbound1 upperbound1 spend_cf if fakedata==1,lpattern(dash) lcolor(black) yaxis(2)) ///
(connected est_correct0 spend_cf if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)) ///
(connected est_correct1 spend_cf if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)), legend(order(5 "Right about two top parties" 4 "Don't know or wrong")) ///
xtitle("Centrifugalism (spending)") ytitle("Pr(ex post hopeless vote)",axis(2)) ytitle("Percent of the sample",axis(1)) name(expenses,replace)

use mysample,clear
mi estimate,post saving(m6,replace): probit xphopeless c.activ_cf##i.correct partymark sidviable sidnviable,cluster(district)
foreach var of varlist partymark sidviable sidnviable {
quietly sum `var'
scalar mean`var'=(r(mean))
}
clear
set obs 21
foreach var in partymark sidviable sidnviable {
gen `var'=`=mean`var''
}

gen activ_cf=(_n-1)*0.05

gen correct=.
forvalues j = 0/1 {
replace correct=`j'
predict xb_mi`j',xb
predict se_mi`j',stdp
gen est_correct`j'=normal(xb_mi`j')
gen lowerbound`j'= normal(xb_mi`j'-1.95*se_mi`j')
gen upperbound`j'= normal(xb_mi`j'+1.95*se_mi`j')
}
gen fakedata=1
append using mysample
twoway (hist activ_cf if fakedata==.,bin(10) yaxis(1) percent yscale(alt) bstyle(p10bar)) /// 
(rline lowerbound0 upperbound0 activ_cf if fakedata==1,lpattern(dash) lcolor(black) yaxis(2) yscale(alt axis(2))) ///
(rline lowerbound1 upperbound1 activ_cf if fakedata==1,lpattern(dash) lcolor(black) yaxis(2)) ///
(connected est_correct0 activ_cf if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)) ///
(connected est_correct1 activ_cf if fakedata==1,lpattern(solid) lcolor(black) yaxis(2)), legend(order(5 "Right about two top parties" 4 "Don't know or wrong")) ///
xtitle("Centrifugalism (activism)") ytitle("Pr(ex post hopeless vote)",axis(2)) ytitle("Percent of the sample",axis(1)) nodraw name(activists,replace)

grc1leg activists expenses,ycommon legendfrom(activists) iscale(1)
graph display,xsize(6.5)
graph export figure3.eps,replace

* summary statistics
use mysample,clear
sutex correct xphopeless campden activ_volume activ_cf spend_volume spend_cf ptyid_volume ptyid_cf interest wr_education ///
wr_knowledge wr_tv partymark sfratio contacted sidviable sidnviable,minmax label
corr correct xphopeless campden activ_volume activ_cf spend_volume  spend_cf ptyid_volume ptyid_cf interest ///
wr_education wr_knowledge wr_tv partymark sfratio contacted sidviable sidnviable 
mi convert flong
misum correct xphopeless campden activ_volume activ_cf spend_volume spend_cf ptyid_volume ptyid_cf interest wr_education ///
 wr_knowledge wr_tv partymark sfratio contacted sidviable sidnviable
