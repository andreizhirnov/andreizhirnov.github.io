clear all
* findit wridit
* net install wridit.pkg

use CES2011extract.dta,clear 
keep FED_NAME_11 CPS11_44 CPS11_45 PES11_6 CPS11_13 CPS11_71 PES11_59a CPS11_72 PES11_59b PES11_74 CPS11_9 ///
MBS11_K11 CPS11_78 MBS11_L1 CPS11_78 CPS11_69 MBS11_K14 CPS11_70 CPS11_68 CPS11_79

* prepare riding names for merging with the file with additional variables
drop if FED_NAME_11=="" 
gen dname=lower(FED_NAME_11)
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","a")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","o")
replace dname=regexr(dname,"�","e") 
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","i")
replace dname=regexr(dname,"2","")
replace dname=regexr(dname,"3","")
split dname,p("/") gen(dnamep)
replace dname=trim(dnamep1)
drop dnamep*
replace dname=itrim(dname)
replace dname="desnethe-missinippi-churchill river" if regexm(dname,"desneth") 
replace dname="haute-gaspesie-la mitis-matane-matapedia" if regexm(dname,"haute-gaspesie")
replace dname="chateauguay-saint-constant" if dname=="cheteauguay-saint-constant"
replace dname="gaspesie-iles-de-la-madeleine" if dname=="gaspeie-iles-de-la-madelei"
replace dname="hull-aylmer" if regexm(dname,"hull-aylmer")
replace dname="jonquiere-alma" if regexm(dname,"jonquiere-alma")
replace dname="la pointe-de-l'ile" if regexm(dname,"la pointe-de-lile")
replace dname="levis-bellechasse" if regexm(dname,"levis-bellechass")
replace dname="lotbiniere-chutes-de-la-chaudiere" if regexm(dname,"lotbiniere-chutes-de-la-chaudie")
replace dname="louis-hebert" if regexm(dname,"louis-heber")
replace dname="mount royal" if regexm(dname,"mont-royal")
replace dname="quebec" if dname=="quebe"
replace dname="rimouski-neigette-temiscouata-les basques" if regexm(dname,"rimouski-neigette-temiscouata-les bas")
replace dname="saint-bruno-saint-hubert" if regexm(dname,"saint-bruno-saint-hubert")
replace dname="wild rose" if regexm(dname,"wild rose")
merge m:1 dname using additionalvar.dta					/* file with additional variables */
assert _merge!=1
keep if _merge==3
drop _merge
merge m:1 district using estimated_id,nogenerate
merge m:1 district using estimated_cct,nogenerate
merge m:1 district using estimated_activ,nogenerate

* Respondent guesses the winner
recode CPS11_44 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(6=6)(98/99=.),gen(projwinner)
recode CPS11_44 (98=1)(99=.)(nonmissing=0),gen(dnkwinner)
* Respondent predicts the party with the second highest chance for winning
recode CPS11_45 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(6=6)(7=.)(98/99=.),gen(projrunnerup)
recode CPS11_45 (98=1)(99=.)(nonmissing=0),gen(dnkrunnerup)
* Vote choice
recode PES11_6 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(7/8=0)(98/99=.),gen(votechoice)
recode CPS11_13 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(7/8=0)(98/99=.),gen(t_votechoice2) /* 1 BQ, 2 Con, 3 Green, 4 Lib, 5 NDP, 6 Others */ 
replace votechoice=t_votechoice2 if votechoice==. 
* Strong party id
recode CPS11_71 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(6/9=0),gen(t_idparty1)
recode PES11_59a (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(6/9=0),gen(t_idparty2)
recode CPS11_72 (1=1)(nonmissing=0),gen(t_strongid1)
recode PES11_59b (1=1)(nonmissing=0),gen(t_strongid2)
gen strongid=t_strongid1
replace strongid=t_strongid2 if strongid==.
gen sidparty=t_idparty1*t_strongid1
replace sidparty=t_idparty2*t_strongid2 if sidparty==.
* interest in federal election
gen interest=CPS11_9
mvdecode interest,mv(98 99)
* contacted
recode MBS11_K11 (2=0)(1=1)(else=.),gen(contacted)
* age
mvdecode CPS11_78,mv(9999)
mvdecode  MBS11_L1,mv(-9999)
gen t_yrborn=CPS11_78
replace t_yrborn=MBS11_L1 if t_yrborn==.
gen age=2011-t_yrborn
* knowledge
gen t_1=0 if CPS11_69!=.|MBS11_K14!=.
replace t_1=1 if inlist(CPS11_69,1,3)
replace t_1=1 if inlist(MBS11_K14,3) 
gen t_2=0 if CPS11_70!=.
replace t_2=1 if inlist(CPS11_70,1,3) 
gen t_3=1 if CPS11_68!=.
replace t_3=0 if inlist(CPS11_68,97,98,99)
                   // t_1  - federal financial minister; t_2 - governor-general; t_3 - provincial premier
gen knowledge=t_1+t_2+t_3
wridit knowledge,gen(wr_knowledge)
* Education
gen education=CPS11_79
mvdecode education,mv(98 99)
wridit education,gen(wr_education)
* TV watching
gen tv = PES11_74
mvdecode tv,mv(98)
wridit tv,gen(wr_tv)
* Identification
gen sidviable=0 if sidparty!=.
replace sidviable=1 if sidparty==winner|sidparty==runnerup 
gen sidnviable=strongid-sidviable

drop if votechoice==.|winner==.|runnerup==.
keep if projrunnerup!=.|dnkrunnerup==1
keep if projwinner!=.|dnkwinner==1 

* clean up and label
drop CPS* PES* MBS* FED* t_*

lab var dname "The name of the federal riding"
lab var projwinner "Expected winner"
lab var projrunnerup "Expected runnerup"
lab var dnkwinner "Respondent acknowledged not knowing the winner"
lab var dnkrunnerup "Respondent acknowledged not knowing the runnerup"
lab var votechoice "Reported vote choice"
lab var strongid "Strong partisan"
lab var sidparty "Party of a strong partisan affinity"
lab var interest "Interest in federal election"
lab var contacted "Contacted by a party'
lab var age "Age"
lab var knowledge "Political knowledge"
lab var wr_knowledge "Political knowledge (ridit)"
lab var education "Education"
lab var wr_education "Education (ridit)"
lab var tv "Exposure to TV news"
lab var wr_tv "Exposure to TV news (ridit)"
lab var sidviable "Strong affinity to a party of an ex post viable candidate"
lab var sidnviable "Strong affinity to a party of an ex post non-viable candidate"
lab define party 1 "Bloc Quebecois" 2 "Conservative" 3 "Green" 4 "Liberal" 5 "New Democratic Party" 6 "Other",modify
lab val sidparty party
lab val votechoice party
lab val projwinner party
lab val projrunnerup party

save mainfile,replace
