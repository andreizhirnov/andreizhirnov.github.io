clear all

********************** Survey for 2004 and 2006
use CES20046extract.dta,clear
keep fed03 fed0306 cps_q* pes_k*

rename fed03 district
replace district=fed0306 if district==.
recode cps_q1a (0=0)(1=4)(2=2)(3=5)(4=1)(6=2)(8=3)(97=6)(98/99=0),gen(identifiedparty1)
recode cps_q1b (0=0)(1=4)(2=2)(3=5)(4=1)(6=2)(8=3)(9/10=6)(98/99=0),gen(identifiedparty2)
recode pes_k1a (0=6)(1=4)(2=2)(3=5)(4=1)(6=2)(8=3)(96/99=0),gen(identifiedparty3)
recode pes_k1b (0=6)(1=4)(2=2)(3=5)(4=1)(6=2)(8=3)(9=6)(96/99=0),gen(identifiedparty4)
recode cps_q1a0 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(97/99=0),gen(identifiedparty5)
recode cps_q1b0 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(9=6)(97/99=0),gen(identifiedparty6)
recode  pes_k1a0 (0=6)(1=4)(2=2)(3=5)(4=1)(5=5)(97/99=0),gen(identifiedparty7)
recode pes_k1b0 (0=6)(1=4)(2=2)(3=5)(4=1)(5=5)(9=6)(97/99=0),gen(identifiedparty8)

recode cps_q2 (1=1)(nonmissing=0),gen(strongid1)
recode pes_k2 (1=1)(nonmissing=0),gen(strongid2)
recode cps_q20 (1=1)(nonmissing=0),gen(strongid3)
recode pes_k20 (1=1)(nonmissing=0),gen(strongid4)

gen identifiedparty2004=identifiedparty1*strongid1
replace identifiedparty2004=identifiedparty2*strongid1 if identifiedparty2004==.
replace identifiedparty2004=identifiedparty3*strongid2 if identifiedparty2004==.
replace identifiedparty2004=identifiedparty4*strongid2 if identifiedparty2004==.
gen marker2004=1 if identifiedparty2004!=.

gen identifiedparty2006=identifiedparty5*strongid3
replace identifiedparty2006=identifiedparty6*strongid3 if identifiedparty2006==.
replace identifiedparty2006=identifiedparty7*strongid4 if identifiedparty2006==.
replace identifiedparty2006=identifiedparty8*strongid4 if identifiedparty2006==. 
gen marker2006=1 if identifiedparty2006!=.

foreach y in 2004 2006 {
forvalues j = 0/6 {
gen identparty`y'k`j'=0
replace identparty`y'k`j'=1 if identifiedparty`y'==`j'
}
}

collapse (sum) identparty* (sum) sample2004=marker2004 sample2006=marker2006,by(district)
reshape long identparty2004k identparty2006k ,i(district sample2004 sample2006) j(altern) 

rename (identparty2004k identparty2006k sample2004 sample2006)(identparty1 identparty2 sample1 sample2)
reshape long identparty sample,i(district altern) j(snumber)
drop if district==.|sample==0
replace identparty=0 if identparty==.
tempfile running
save `running',replace

********************* Survey 2008 
use CES2008extract.dta,clear
keep fed_name_08 ces08_cps_q1 ces08_cps_q2 ces08_pes_k1 ces08_pes_k2

destring fed_name_08,gen(district)
gen t_1=floor(district/1000)
gen t_diff=district-1000*t_1
drop if t_diff==999|district==.		/* remove the observations without a valid district code */
drop t_*
recode ces08_cps_q1a (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(97/99=0),gen(identifiedparty1)
recode ces08_pes_k1 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(97/99=0),gen(identifiedparty2) 

recode ces08_cps_q2 (1=1)(nonmissing=0),gen(strongid1)
recode ces08_pes_k2 (1=1)(nonmissing=0),gen(strongid2)

gen identifiedparty=identifiedparty1*strongid1
replace identifiedparty=identifiedparty2*strongid2 if identifiedparty==.
gen marker=1 if identifiedparty!=.
forvalues j = 0/6 {
gen identparty`j'=0
replace identparty`j'=1 if identifiedparty`y'==`j'
}
collapse (sum) identparty* (sum) sample=marker,by(district)
reshape long identparty ,i(district sample) j(altern)
drop if district==.|sample==0
replace identparty=0 if identparty==.
gen snumber=3
append using `running'
save `running',replace

********************* Survey 2011
use CES2011extract.dta,clear 
keep FED_NAME_11 CPS11_71 CPS11_72 PES11_59a PES11_59b

drop if FED_NAME_11=="" 
gen dname=lower(FED_NAME_11)
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","a")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","o")
replace dname=regexr(dname,"�","e") 
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","i")
replace dname=regexr(dname,"2","")
replace dname=regexr(dname,"3","")
split dname,p("/") gen(dnamep)
replace dname=trim(dnamep1)
drop dnamep*
replace dname=itrim(dname)
replace dname="desnethe-missinippi-churchill river" if regexm(dname,"desneth") 
replace dname="haute-gaspesie-la mitis-matane-matapedia" if regexm(dname,"haute-gaspesie")
replace dname="chateauguay-saint-constant" if dname=="cheteauguay-saint-constant"
replace dname="gaspesie-iles-de-la-madeleine" if dname=="gaspeie-iles-de-la-madelei"
replace dname="hull-aylmer" if regexm(dname,"hull-aylmer")
replace dname="jonquiere-alma" if regexm(dname,"jonquiere-alma")
replace dname="la pointe-de-l'ile" if regexm(dname,"la pointe-de-lile")
replace dname="levis-bellechasse" if regexm(dname,"levis-bellechass")
replace dname="lotbiniere-chutes-de-la-chaudiere" if regexm(dname,"lotbiniere-chutes-de-la-chaudie")
replace dname="louis-hebert" if regexm(dname,"louis-heber")
replace dname="mount royal" if regexm(dname,"mont-royal")
replace dname="quebec" if dname=="quebe"
replace dname="rimouski-neigette-temiscouata-les basques" if regexm(dname,"rimouski-neigette-temiscouata-les bas")
replace dname="saint-bruno-saint-hubert" if regexm(dname,"saint-bruno-saint-hubert")
replace dname="wild rose" if regexm(dname,"wild rose")
merge m:1 dname using additionalvar.dta,keepusing(district)			/* file with additional variables */
assert _merge!=1
keep if _merge==3
drop _merge

recode CPS11_71 (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(6/9=0),gen(identifiedparty1)
recode PES11_59a (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(6/9=0),gen(identifiedparty2)
recode CPS11_72 (1=1)(nonmissing=0),gen(strongid1)
recode PES11_59b (1=1)(nonmissing=0),gen(strongid2)

gen identifiedparty=identifiedparty1*strongid1
replace identifiedparty=identifiedparty2*strongid2 if identifiedparty==.
gen marker=1 if identifiedparty!=.
forvalues j = 0/6 {
gen identparty`j'=0
replace identparty`j'=1 if identifiedparty`y'==`j'
}
 
collapse (sum) identparty* (sum) sample=marker,by(district)
reshape long identparty ,i(district sample) j(altern)
drop if district==.|sample==0
replace identparty=0 if identparty==.
gen snumber=4
append using `running' 
save `running',replace

********* calculate the averages
gen share=identparty/sample
gen province=floor(district/1000)
collapse (mean) share,by(district altern)
merge m:1 district using additionalvar,keepusing(winner runnerup)
keep if _merge==3
drop _merge
sum share if altern==6
drop if altern==6             /* matching by category "others" is not meaningful */
gen markall=(altern>0)
gen marknviable=markall
replace marknviable=0 if altern==winner
replace marknviable=0 if altern==runnerup
gen idall=share*markall
gen idnviable=share*marknviable
collapse (sum) ptyid_volume=idall ptyid_cf=idnviable,by(district) 
replace ptyid_cf=ptyid_cf/ptyid_volume 
lab var district "Federal riding"
lab var ptyid_volume "Prop. strong partisans"
lab var ptyid_cf "Centrifugalism (party id)"
save estimated_id,replace
