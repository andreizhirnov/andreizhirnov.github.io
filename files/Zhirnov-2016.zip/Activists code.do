use CES2008extract,clear 
keep fed_name_08 ces08_mbs_f3 ces08_mbs_f4 ces08_mbs_f5 ces08_mbs_f6 ces08_mbs_f7 ces08_mbs_f8 ///
ces08_pes_b1 ces08_pes_b4b ces08_cps_s3 ces08_mbs_l1

destring fed_name_08,gen(district)
gen t_1=floor(district/1000)
gen t_diff=district-1000*t_1
drop if t_diff==999|district==.		/* remove the observations without a valid district code */
drop t_*

merge m:1 district using additionalvar,nogenerate

* agegroup  
gen age=2008-1900-ces08_mbs_l1 if ces08_mbs_l1!=999
gen agegroup=.
replace agegroup=1 if inrange(age,18,19)
replace agegroup=2 if inrange(age,20,24)
replace agegroup=3 if inrange(age,25,29)
replace agegroup=4 if inrange(age,30,34)
replace agegroup=5 if  inrange(age,35,39)
replace agegroup=6 if  inrange(age,40,44) 
replace agegroup=7 if  inrange(age,45,49)
replace agegroup=8 if  inrange(age,50,54)
replace agegroup=9 if  inrange(age,55,59)
replace agegroup=10 if inrange(age,60,64)
replace agegroup=11 if inrange(age,65,69)
replace agegroup=12 if inrange(age,70,74) 
replace agegroup=13 if inrange(age,75,79)
replace agegroup=14 if inrange(age,80,84) 
replace agegroup=15 if age>=85&age!=.           /* these are the agegroups present in the census */

recode ces08_cps_s3 (1/8=0)(9/11=1)(98/99=.),gen(badegree)

recode ces08_pes_b4b (0=6)(1=4)(2=2)(3=5)(4=1)(5=3)(98/99=.),gen(altern)
replace altern=0 if ces08_pes_b1==5         /* non-voters */
keep if inlist(altern,0,1,2,3,4,5) 
egen ptygr=group(altern district) if altern!=.&altern!=6
forvalue j = 0/5 {
gen votefor`j'=(altern==`j')
}

gen province=floor(district/1000)
tempfile main
save `main',replace

recode province (24=1)(35=2)(46/48=3)(59=3)(nonmissing=4),gen(region)
drop if badegree==.|agegroup==.|region==.
collapse (mean) votefor*,by(region agegroup badegree)
tempfile temp
save `temp',replace

***********************************************************************
import excel ActivistsJointDistrib.xlsx, firstrow clear 

egen x_ba=rowtotal(x_*_ba_inc*)
egen x_nba=rowtotal(x_*_nba_inc*)
drop x_*_ba_inc* x_*_nba_inc*
rename (x_ba x_nba)(x_1 x_0)
reshape long x_,i(district agegroup) j(badegree)
gen province=floor(district/1000)
recode province (24=1)(35=2)(46/48=3)(59=3)(nonmissing=4),gen(region)
merge m:1 region agegroup badegree using `temp'
keep if _merge==3

forvalues j = 0/5 { 
gen x`j'bad=votefor`j'*x_
}

drop _merge votefor* x_

reshape wide x0bad x1bad x2bad x3bad x4bad x5bad,i(district region province agegroup) j(badegree)
rename (*bad*)(*bad*f)
reshape wide x0bad1f x1bad1f x2bad1f x3bad1f x4bad1f x5bad1f x0bad0f x1bad0f x2bad0f x3bad0f x4bad0f x5bad0f,i(district region province) j(agegroup)

forvalues u= 0/5 {
forvalues m = 0/1 {
forvalues a = 1/15 {
local k=`u'*30 + `m'*15 + `a'
rename x`u'bad`m'f`a' group`k'
replace group`k'=0 if group`k'==.
}
}
}
egen dtotal=rowtotal(group*)
foreach var of varlist group* {
replace `var'=`var'/dtotal
}
drop dtotal 

forvalues j = 2/180 {
local k=`j'-1
replace group`j'=group`k'+group`j'
}

forvalues j = 1/180 { 
replace group`j'=round(2000*group`j')
}

expand 2000
sort district
gen id=1 if district!=district[_n-1]
replace id=id[_n-1]+1 if id==. 
gen altern=0
gen badegree=0
gen agegroup=0

gen group0=0

forvalues j = 0/5 { 
local low=`j'*30 
local high=(`j'+1)*30
replace altern=`j' if id>group`low'&id<=group`high'
}

forvalues j = 0/5 { 
forvalues m = 0/1 {
local low=(`j'*2+`m')*15
local high=(`j'*2+`m'+1)*15
replace badegree=`m' if id>group`low'&id<=group`high'
}
}

forvalues j = 0/11 { 
forvalues f = 1/15 {
local low=`j'*15 + `f' - 1
local high=`j'*15 + `f'
replace agegroup=`f' if id>group`low'&id<=group`high'
} 
}
drop group* 

merge m:1 district using additionalvar,nogenerate
tempfile simulated
save `simulated',replace
 
use `main',clear
mvdecode ces08_mbs_f3 ces08_mbs_f4 ces08_mbs_f5 ces08_mbs_f7,mv(-9,8)
recode ces08_mbs_f3 (1/2=1)(3/4=0),gen(camp_talked)
recode ces08_mbs_f4 (1/2=1)(3/4=0),gen(camp_showed)
recode ces08_mbs_f5 (5=0),gen(camp_donparty)
replace camp_donparty=0 if ces08_mbs_f6==5
recode ces08_mbs_f7 (5=0),gen(camp_doncand)
replace camp_doncand=0 if ces08_mbs_f8==5
pwcorr camp_talked camp_showed camp_donparty camp_doncand
gen camp_act=camp_talked+camp_showed+camp_donparty+camp_doncand 
replace camp_act=1 if camp_act!=.&camp_act>0
gen ca_nonmiss=1 if camp_act!=.

keep if inlist(altern,1,2,3,4,5)
gllamm camp_act agegroup badegree votefor1 votefor3 votefor4 votefor5,i(ptygr district province) adapt nrf(1,1,1) link(logit) fam(binom) 
matrix beta=e(b)
gllapred int1,u 

collapse (mean) int1*,by(altern district province)
merge 1:m altern district using `simulated'

forvalues j = 0/5 {
gen votefor`j'=(altern==`j') 
}

matrix score xb=beta,equation(camp_act) 
gen prob=1/(1+exp(-xb-int1m1-int1m2-int1m3))
replace prob=0 if altern==0 
collapse (sum) active=prob (count) sample=prob,by(altern district province)

merge m:1 district using additionalvar,nogenerate
gen markall=(altern>0)
gen marknviable=markall
replace marknviable=0 if altern==winner
replace marknviable=0 if altern==runnerup
gen actall=active*markall
gen actnviable=active*marknviable
collapse (sum) actall activ_cf=actnviable sample,by(district) 
gen activ_volume=actall/sample
replace activ_cf=activ_cf/actall
keep district activ_volume activ_cf
lab var district "Federal riding"
lab var activ_volume "Aggregate activist support"
lab var activ_cf "Centrifugalism (activists)"
save estimated_activ,replace
