clear all

/* Simulated data */
import excel CampDenJointDistrib.xlsx, firstrow clear
drop _TYPE_ _FREQ_ 
rename (urb_male_fr rur_male_fr urb_female_fr rur_female_fr urb_male_eng rur_male_eng urb_female_eng rur_female_eng)(value#f),addnumber
foreach var of varlist value*f {
replace `var'=0 if `var'==.
}

reshape wide value1f value2f value3f value4f value5f value6f value7f value8f,i(district) j(agegroup)

forvalues j = 1/15 {
forvalues m = 1/8 {
local k=(`m'-1)*15+`j'
rename value`m'f`j' group`k'
}
}

egen dtotal=rowtotal(group*)
foreach var of varlist group* {
replace `var'=`var'/dtotal
}
drop dtotal 

forvalues j = 2/120 {
local k=`j'-1
replace group`j'=group`k'+group`j'
}

forvalues j = 1/120 { 
replace group`j'=round(2000*group`j')
}

expand 2000
sort district
gen id=1 if district!=district[_n-1]
replace id=id[_n-1]+1 if id==.
gen frenchspeaking=0
gen female=0
gen urban=0
gen agegroup=0

replace frenchspeaking=1 if id<=group60
replace female=1 if (id<=group60&id>group30)|(id<=group120&id>group90)
replace urban=1 if (id<=group15)|(id<=group45&id>group30)|(id<=group75&id>group60)|(id<=group105&id>group90)
forvalues j = 1/8  {
local u=(`j'-1)*15+1
replace agegroup=1 if id<=group`u'
forvalues k = 2/15 {
local m=(`j'-1)*15+`k'
local f=`m'-1
replace agegroup=`k' if id<=group`m'&id>group`f'
}
}
drop group*

gen province=floor(district/1000)

merge m:1 district using additionalvar,nogenerate
tempfile simulated
save `simulated',replace

/* estimation sample */
use CES2011extract.dta,clear 
keep FED_NAME_11 RGENDER11 MBS11_L2 BLKURB_11  MBS11_K11 

drop if FED_NAME_11=="" 
gen dname=lower(FED_NAME_11)
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname," - ","-")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","a")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","o")
replace dname=regexr(dname,"�","e") 
replace dname=regexr(dname,"�","e")
replace dname=regexr(dname,"�","i")
replace dname=regexr(dname,"2","")
replace dname=regexr(dname,"3","")
split dname,p("/") gen(dnamep)
replace dname=trim(dnamep1)
drop dnamep*
replace dname=itrim(dname)
replace dname="desnethe-missinippi-churchill river" if regexm(dname,"desneth") 
replace dname="haute-gaspesie-la mitis-matane-matapedia" if regexm(dname,"haute-gaspesie")
replace dname="chateauguay-saint-constant" if dname=="cheteauguay-saint-constant"
replace dname="gaspesie-iles-de-la-madeleine" if dname=="gaspeie-iles-de-la-madelei"
replace dname="hull-aylmer" if regexm(dname,"hull-aylmer")
replace dname="jonquiere-alma" if regexm(dname,"jonquiere-alma")
replace dname="la pointe-de-l'ile" if regexm(dname,"la pointe-de-lile")
replace dname="levis-bellechasse" if regexm(dname,"levis-bellechass")
replace dname="lotbiniere-chutes-de-la-chaudiere" if regexm(dname,"lotbiniere-chutes-de-la-chaudie")
replace dname="louis-hebert" if regexm(dname,"louis-heber")
replace dname="mount royal" if regexm(dname,"mont-royal")
replace dname="quebec" if dname=="quebe"
replace dname="rimouski-neigette-temiscouata-les basques" if regexm(dname,"rimouski-neigette-temiscouata-les bas")
replace dname="saint-bruno-saint-hubert" if regexm(dname,"saint-bruno-saint-hubert")
replace dname="wild rose" if regexm(dname,"wild rose")

merge m:1 dname using additionalvar.dta
assert _merge!=1
keep if _merge==3
drop _merge
* gender
gen female=0 if RGENDER11==1
replace female=1 if RGENDER11==5
replace female=0 if MBS11_L2==1
replace female=1 if  MBS11_L2==5
* urban residence
destring BLKURB_11,replace
recode BLKURB_11 (1=1)(0=0)(*=.),gen(urban)
* contacted
recode MBS11_K11 (2=0)(1=1)(else=.),gen(contacted)
* province
gen province=floor(district/1000)

/* estimation */
gllamm contacted urban female propfrenchspeaking lowuhw,i(district province) adapt nrf(1,1) link(logit) fam(binom)
matrix beta=e(b)
gllapred int,u
collapse (mean) m1 m2 s1 s2,by(district)
merge 1:m district using `simulated'
matrix score xb=beta,equation(contacted)
gen prob=1/(1+exp(-xb-m1-m2))
collapse (mean) campden=prob,by(district)
lab var district "Federal riding"
lab var campden "Density of campaign contacts"
save estimated_cct,replace
