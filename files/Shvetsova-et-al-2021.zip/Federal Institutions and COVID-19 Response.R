
##########################################################################
## This code reproduces the analysis presented in 
##S hvetsova O, VanDusky-Allen J, Zhirnov A, Adeel AB, Catalano M,
## Catalano O, Giannelli F, Muftuoglu E, Rosenberg D, Sezgin MH and Zhao T
## (2021) Federal Institutions and Strategic Policy Responses to COVID-
## 19 Pandemic. Frontiers in Political Science 3:631363.
## doi: 10.3389/fpos.2021.631363
##########################################################################

library(ggplot2)

theme_set(theme_bw() + theme(strip.text.x =element_text(size=14, family="serif"), 
                             strip.text.y =element_text(size=14, family="serif"),  
                             axis.title.x =element_text(size=14, family="serif"), 
                             axis.title.y =element_text(size=14, family="serif"), 
                             axis.text=element_text(size=12, family="serif"),
                             legend.text=element_text(size=12, family="serif")))

rm(list=ls())
options(stringsAsFactors = FALSE)
 
country <- readRDS("Federal Institutions and COVID-19 Response.rds")
feds <- subset(country, fed==1)

cor.test(feds$ratio.nat_total,feds$next_election)
cor(subset(feds, presidential==0, select=c("ratio.nat_total","enlp")))

# PPI in federations and non-federations
pic <- ggplot(country, aes(x=n_RAI, y=ppi, shape=as.factor(fed))) + 
  geom_point(size=2, color="black") + 
  scale_shape_manual(breaks=c(1,0), values=c(17,1), labels = c("Federation", "Non-federation")) +  
  labs(shape=element_blank(), x="Regional Authority Index", y="Avg Total PPI") +
  theme(legend.position="bottom", legend.text = element_text(size = 14))
ggsave("figure-1.tiff", pic, width=5, height=5, compression="lzw") 


## Distribution of PPI
bulk.wide <- subset(country, !is.na(fed), select=c("isocode","fed","ppi","ppi_n","ppi_s" ))
bulk <- reshape(bulk.wide, direction="long", idvar="isocode",
                times = c("ppi","ppi_n","ppi_s"),
                timevar = "measure",
                v.names = "value",
                varying = list(c("ppi","ppi_n","ppi_s"))
                )
rownames(bulk) <- NULL
bulk <- within(bulk, {
  sample <- factor(fed, levels=c(0,1), labels=c("Non-federations","Federations"))  
  measure <- factor(measure, levels=c("ppi","ppi_n","ppi_s"), 
                    labels=c("Avg Total PPI","National PPI","Avg Regional PPI"))
})
bulk <- bulk[order(bulk$sample),] 

pic <- ggplot(bulk, aes(x=value)) + 
  geom_histogram(bins=10, size=1, alpha=0.3, aes(y = ..density.., group=interaction(sample, measure)), color="blue", fill="blue") +
  facet_grid(sample ~ measure) +
  labs(y="Density", x="PPI") +
  theme(legend.position="bottom", legend.text = element_text(size = 14))
ggsave("figure-2.tiff", pic, width=8, height=5, compression="lzw") 

aggregate(value ~ sample + measure, data=bulk, FUN=mean)
cor(feds[c("ppi_n","ppi_s")])

## Plotting
mixedlabs <- function(criteria, lags) {
  crit <- do.call("rbind", criteria)
  target <- data.frame(crit, tid=1:length(criteria)) 
  club <- merge(feds, target, by=NULL, suffixes=c("",".c"))
  for (var in colnames(crit)) {
    club <- club[abs(club[[var]]-club[[paste0(var,".c")]])<=lags[var],]
  }
  a <- aggregate(x= club[,colnames(crit)], by=list(tid=club$tid), FUN=mean)
  club.l <- lapply(unique(club$tid), function(j) {
    y <- subset(club, tid==j)
    if (length(y$ccodealp) %in% 1:2) {
      lab <- paste(y$ccodealp, collapse="\n")
    } else if (length(y$ccodealp) %in% 3:4) {
      lab <- paste(c(paste0(y$ccodealp[1:(length(y$ccodealp)-1)],c(",","\n")), y$ccodealp[length(y$ccodealp)]), collapse="")
    } else {
      lab <- paste(c(paste0(y$ccodealp[1:(length(y$ccodealp)-1)],c(",",",","\n")), y$ccodealp[length(y$ccodealp)]), collapse="")
    }
    data.frame(ccodealp=lab, subset(a, tid==j))
  })
  reg.l <- subset(feds, !(ccodealp %in% club$ccodealp), select=c("ccodealp", colnames(crit)))
  club.l <- do.call("rbind", club.l)
  list(r=reg.l, m=club.l)
}

mlabs <- mixedlabs(criteria = list(c(ppi_n=0.7,ppi_s=0)), lags = c(ppi_n=0.05,ppi_s=0.05))

pic <- ggplot(feds, aes(x=ppi_n, y=ppi_s) ) + 
  geom_text(aes(label=ccodealp), data=mlabs$r, size=3) +
  geom_label(aes(label=ccodealp), data=mlabs$m, size=3) + 
  expand_limits(x=c(0,1), y=c(0,1)) +
  labs(x="National PPI", y="Avg Regional PPI")
ggsave("figure-3.tiff", pic, width=6, height=6, compression="lzw")   


## figure 4
mlabs <- mixedlabs(criteria = list(c(ratio.nat_total=0.8,ratio.subn_total=0.3),
                                   c(ratio.nat_total=1.05,ratio.subn_total=-0.05)), 
                   lags = c(ratio.nat_total=0.06, ratio.subn_total=0.06))

pic <- ggplot(feds, aes(x=ratio.nat_total, y=ratio.subn_total) ) + 
  geom_text(aes(label=ccodealp), data=mlabs$r, size=3) +
  geom_label(aes(label=ccodealp), data=mlabs$m, size=3) + 
  expand_limits(x=c(0,1.07), y=c(0,1)) +
  geom_abline(intercept=1, slope=-1, linetype="dashed") +
  scale_x_continuous(breaks=seq(0,1,0.25)) +
  labs(x="National /Avg Total PPI", y="Avg Regional /Avg Total PPI")
ggsave("figure-4.tiff", pic, width=6, height=6, compression="lzw")  

# figure 5
mlabs <- mixedlabs(criteria = list(c(next_election=43, ratio.nat_total=1.05, presidential=0),
                                   c(next_election=42, ratio.nat_total=1.05, presidential=1)), 
                   lags = c(next_election=2, ratio.nat_total=0.06, presidential=0))

preslab <- c("0"="Parliamentary", "1"="Presidential")

pic <- ggplot(data=feds, aes(y=ratio.nat_total, x=next_election)) + 
  geom_text(aes(label=ccodealp), data=mlabs$r, size=3) +
  geom_label(aes(label=ccodealp), data=mlabs$m, size=3) + 
  geom_smooth(method="lm") + 
  facet_grid(.~ presidential, scales="free_x", labeller=labeller(presidential=preslab)) +
  labs(x="Months until the next election", y="National / Avg Total PPI") 
ggsave("figure-5.tiff", pic, width=8, height=6, compression="lzw")  

# figure 6
mlabs <- mixedlabs(criteria = list(c(np_fedexec=4, ratio.nat_total=1.05),
                                   c(np_fedexec=1, ratio.nat_total=1.05)), 
                   lags = c(np_fedexec=0.06, ratio.nat_total=0.06))

pic <- ggplot(data=feds, aes(y=ratio.nat_total, x=np_fedexec)) + 
  geom_text(aes(label=ccodealp), data=mlabs$r, size=3) +
  geom_label(aes(label=ccodealp), data=mlabs$m, size=3) + 
  geom_smooth(method="lm") +
  labs(x="Number of parties in the federal executive", y="National / Avg Total PPI")
ggsave("figure-6.tiff", pic, width=8, height=6, compression="lzw")  


# figure 7
mlabs <- mixedlabs(criteria = list(c(enlp=2.3, ratio.nat_total=1.05, presidential=1)), 
                   lags = c(enlp=0.5, ratio.nat_total=0.06, presidential=0))

pic <- ggplot(data=feds, aes(y=ratio.nat_total, x=enlp)) +
  geom_text(aes(label=ccodealp), data=mlabs$r, size=3) +
  geom_label(aes(label=ccodealp), data=mlabs$m, size=3) +  
  geom_smooth(method="lm") +
  facet_grid(.~ presidential, scales="free_x", labeller=labeller(presidential=preslab)) +
  labs(x="Effective number of parties in the federal legislature", y="National / Avg Total PPI")
ggsave("figure-7.tiff", pic, width=8, height=6, compression="lzw")  

# figure 10
avg <- aggregate(cbind(ratio.nat_total,ppi) ~ decsp.gov + decsp.fed, data=feds, FUN=mean)

vlab <- c("H" = "Government Role: High", "L" = "Government Role: Low")
hlab <- c("H" = "Federal Government's Accountability\nfor Health: High", 
          "L" = "Federal Government's Accountability\nfor Health: Low")

pic <- ggplot(data=feds, aes(y=ratio.nat_total, x=ppi)) + 
  geom_text(aes(label=ccodealp), size=3) +
  geom_label(label = "average", data = avg, color="red", size=3, alpha=0.2) +  
  facet_grid(decsp.gov ~ decsp.fed, switch ="y", labeller = labeller(decsp.gov=vlab, decsp.fed=hlab)) + 
  scale_y_continuous(position = "right") +
  labs(x="Avg Total PPI", y="National / Avg Total PPI")
ggsave("figure-10.tiff", pic, width=9, height=7, compression="lzw")  

# Appendix
pic <- ggplot(data=subset(feds, !is.na(bloc.lr)), aes(y=ratio.nat_total, x=bloc.lr, group=bloc.lr)) + 
  geom_boxplot() +
  labs(x="Left-right Position of Chief Executive", y="National / Avg Total PPI")
ggsave("figure-A31.tiff", pic, width=5, height=5, compression="lzw") 

pic <- ggplot(data=subset(feds, !is.na(bloc2.lr)), aes(y=ratio.nat_total, x=bloc2.lr, group=bloc2.lr)) + 
  geom_boxplot() +
  labs(x="Left-right Position of Chief Executive", y="National / Avg Total PPI")
ggsave("figure-A32.tiff", pic, width=5, height=5, compression="lzw") 


