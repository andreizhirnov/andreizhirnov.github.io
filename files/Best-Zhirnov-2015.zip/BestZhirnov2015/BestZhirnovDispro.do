/* Replication file for */
/* Best, Robin E. and Andrei Zhirnov. Perils and Pitfalls of Ignoring Disproportionality's Behavioral Component */
/* May 2015 */


clear all
cd "/home/andrei/Desktop/bundle/"
set scheme s1mono,permanent
net install sg77,from(http://www.stata.com/stb/stb42)
use BestZhirnovDispro.dta,clear

* Variation in observed disproportionality within a single system. Figure 2.
twoway (connected gallagher year if nation=="Canada") ///
(connected gallagher year if nation=="United Kingdom") ///
(connected gallagher year if nation=="Germany") ///
(connected gallagher year if nation=="Netherlands"), ///
legend(lab(1 "Canada") lab(2 "United Kingdom") lab(3 "Germany") lab(4 "the Netherlands")) ytitle("Observed disproportionality") ///
xlab(1945(10)2015)
graph export figure2.eps,replace

tabstat gallagher if nation=="Canada"|nation=="Germany"|nation=="United Kingdom"|nation=="Netherlands", ///
statistics(mean min max var) by(nation) 

* Observed disproportionality and average district magnitude. Figure 3.

twoway scatter gallagher adm_d,xscale(log) xlabel(1 2 4 8 16 32 64 128 256) xtitle("Average district magnitude")
graph export figure3.eps,replace

* Observed disproportionality and national legal threshold. Figure 4.

twoway scatter gallagher NatThresh if NatThresh!=0, xtitle("Legal national threshold") 
graph export figure4.eps,replace 

* Observed disproportionality and the presence of a decisive compensatory tier. Figure 5.

tempvar cat
gen `cat'=1 if lgm_dt=="L"
replace `cat'=1 if inlist(lgm_dt,"L,U","L,UU")
replace `cat'=2 if inlist(lgm_dt,"U","UU")
lab define categories 1 "No decisive compensatory tier" 2 "With a decisive compensatory tier"
lab val `cat' categories
graph box gallagher,by(`cat',note(""))
graph export figure5.eps,replace 

* Observed disproportionality and average district magnitude in old and new democracies. Figure 6.

lab define newdem 0 "Old democracies" 1 "New democracies",modify
lab val newdem newdem
twoway scatter gallagher adm_d, by(newdem, note("")) xscale(log) xlabel(1 2 4 8 16 32 64 128 256) ///
ytitle("Disproportionality") xtitle("Average district magnitude""(decisive tier)")
graph export figure6.eps,replace

* Table 1 & parts of Table A.4 

reg gallagher lnadm_d LowtierThresh,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
xi: reg gallagher lnadm_d LowtierThresh i.formula,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
xi: reghv gallagher lnadm_d LowtierThresh, var(lnadm_d LowtierThresh) robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_d LowtierThresh i.formula, var(lnadm_d LowtierThresh i.formula) robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**) onecol
reg gallagher lnadm_d LowtierThresh newdem,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
reg gallagher lnadm_d LowtierThresh if newdem==0,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
reg gallagher lnadm_d LowtierThresh if newdem==1,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)

// Table A.3 & parts of Table A.4

xi: reghv gallagher lnadm_l uppertier LowtierThresh, var(lnadm_l uppertier LowtierThresh) robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lneffdm, var(lneffdm) robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) onecol

xi: reghv gallagher lnadm_l uppertier LowtierThresh i.formula, var(lnadm_l uppertier LowtierThresh i.formula) robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lneffdm i.formula, var(lneffdm i.formula) robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) onecol

reg gallagher lnadm_l uppertier LowtierThresh,robust
outreg2 using tableA3,excel  dec(2) label alpha(0.05) symbol(**)
reg gallagher lneffdm,robust
outreg2 using tableA3,excel  dec(2) label alpha(0.05) symbol(**)

xi: reg gallagher lnadm_l  uppertier LowtierThresh i.formula,robust
outreg2 using tableA3,excel   dec(2) label alpha(0.05) symbol(**)
xi: reg gallagher lneffdm i.formula,robust
outreg2 using tableA3,excel  dec(2) label alpha(0.05) symbol(**)

reg gallagher lnadm_l uppertier LowtierThresh newdem,robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) 
reg gallagher lneffdm newdem,robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**)  

reg gallagher lnadm_l uppertier LowtierThresh if newdem==0,robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) 
reg gallagher lneffdm if newdem==0,robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) 

reg gallagher lnadm_l uppertier LowtierThresh if newdem==1,robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**) 
reg gallagher lneffdm if newdem==1,robust
outreg2 using tableA3,excel dec(2) label alpha(0.05) symbol(**)

// summary statistics -- Tables A1-A2

preserve
quietly reg gallagher adm_d NatThresh
keep if e(sample)
corrtex gallagher lnadm_d lnadm_l lneffdm uppertier LowtierThresh newdem,file(corrtables) noscreen landscape digits(3) longtable
sutex gallagher adm_d adm_l uppertier effdm LowtierThresh newdem,minmax label
tab formula
restore

// Wald test for the variance dependence
eq lpm: gallagher lnadm_d LowtierThresh
eq lpv: lnadm_d LowtierThresh
regh lpm lpv,robust
test [lpv] lnadm_d
test [lpv] LowtierThresh

xi i.formula
eq lpm: gallagher lnadm_d LowtierThresh _Iformula*
eq lpv: lnadm_d LowtierThresh _Iformula*
regh lpm lpv,robust
test [lpv] lnadm_d
test [lpv] LowtierThresh

//// robustness checks for the thresholds

//// Linear regressions  
reg gallagher lnadm_d,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
reg gallagher lnadm_l uppertier,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**) 

xi: reg gallagher lnadm_d i.formula,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**)
xi: reg gallagher lnadm_l  uppertier i.formula,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**) 

reg gallagher lnadm_d  LowtierThresh ,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
reg gallagher lnadm_l uppertier LowtierThresh ,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**) 

xi: reg gallagher lnadm_d LowtierThresh  i.formula,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**)
xi: reg gallagher lnadm_l  uppertier  LowtierThresh i.formula,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**) 

reg gallagher lnadm_d AnyLegalThresh,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
reg gallagher lnadm_l uppertier AnyLegalThresh,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**) 

xi: reg gallagher lnadm_d AnyLegalThresh i.formula,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**)
xi: reg gallagher lnadm_l  uppertier AnyLegalThresh i.formula,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**) 

reg gallagher lnadm_d nrt,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**)
reg gallagher lnadm_l uppertier nrt,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**) 

xi: reg gallagher lnadm_d nrt i.formula,robust
outreg2 using table1,excel  dec(2) label alpha(0.05) symbol(**)
xi: reg gallagher lnadm_l  uppertier nrt i.formula,robust
outreg2 using table1,excel dec(2) label alpha(0.05) symbol(**) 

//// Heteroskedastic models 
xi: reghv gallagher lnadm_d, var(lnadm_d) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier, var(lnadm_l uppertier) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol 

xi: reghv gallagher lnadm_d i.formula, var(lnadm_d i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier i.formula, var(lnadm_l uppertier i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol 

xi: reghv gallagher lnadm_d  LowtierThresh , var(lnadm_d LowtierThresh) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier  LowtierThresh , var(lnadm_l uppertier LowtierThresh ) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol

xi: reghv gallagher lnadm_d  LowtierThresh i.formula, var(lnadm_d LowtierThresh i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier  LowtierThresh i.formula, var(lnadm_l uppertier  LowtierThresh  i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol 

xi: reghv gallagher lnadm_d AnyLegalThresh, var(lnadm_d AnyLegalThresh) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier AnyLegalThresh, var(lnadm_l uppertier AnyLegalThresh) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol 

xi: reghv gallagher lnadm_d AnyLegalThresh i.formula, var(lnadm_d AnyLegalThresh i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier AnyLegalThresh i.formula, var(lnadm_l uppertier AnyLegalThresh i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol

xi: reghv gallagher lnadm_d nrt , var(lnadm_d nrt ) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier nrt , var(lnadm_l uppertier nrt ) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol 

xi: reghv gallagher lnadm_d nrt i.formula, var(lnadm_d  nrt  i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol
xi: reghv gallagher lnadm_l uppertier  nrt  i.formula, var(lnadm_l uppertier nrt  i.formula) robust
outreg2 using table2,excel dec(2) label alpha(0.05) symbol(**) onecol 
